// ============================================================
//  CampuStay — admin.js  (real API)
// ============================================================

var adminProps    = [];
var adminUsers    = [];
var adminBookings = [];
var propFilter    = 'all';
var verifyFilter  = 'all';
var charts        = {};

document.addEventListener('DOMContentLoaded', function() {
  if (!requireAuth('admin')) return;
  populateNavUser();
  loadAdminData();
  switchTab('overview');
});

async function loadAdminData() {
  try {
    var [pd, bd] = await Promise.all([
      apiFetch('/admin/properties?approved=all').catch(function(){ return apiFetch('/properties?approved=all&limit=100'); }),
      apiFetch('/bookings/admin/all').catch(function(){ return {bookings:[]}; })
    ]);
    adminProps    = (pd.properties || []);
    adminBookings = (bd.bookings   || []);
  } catch(e) { adminProps=[]; adminBookings=[]; }
  try {
    var ud = await apiFetch('/admin/users');
    adminUsers = ud.users || [];
  } catch(e) { adminUsers = []; }
  renderOverviewMetrics(); renderPropsTable(); renderUsersTable(); renderBookingsTable(); renderVerifyOwners();
  setTimeout(initCharts, 100);
}

window.switchTab = function(id) {
  document.querySelectorAll('[id^="tab-"]').forEach(function(t){ t.style.display='none'; });
  var panel=document.getElementById('tab-'+id); if(panel) panel.style.display='';
  document.querySelectorAll('[id^="snav-"]').forEach(function(a){ a.classList.remove('active'); });
  var nav=document.getElementById('snav-'+id); if(nav) nav.classList.add('active');
  document.querySelectorAll('.sidebar-item[data-tab]').forEach(function(s){ s.classList.toggle('active',s.dataset.tab===id); });
  if(id==='verify') renderVerifyOwners();
  if(id==='reports') setTimeout(initGrowthChart,200);
};

// ── Overview ──────────────────────────────────────────────
function renderOverviewMetrics() {
  function set(id,v){ var el=document.getElementById(id); if(el) el.textContent=v; }
  set('m-users',    adminUsers.length);
  set('m-props',    adminProps.length);
  set('m-bookings', adminBookings.length);
  set('m-pending',  adminProps.filter(function(p){ return !p.isApproved; }).length);
  set('pending-count', adminProps.filter(function(p){ return !p.isApproved; }).length||'');
  var feedEl=document.getElementById('activity-feed'); if(!feedEl) return;
  var acts=[
    {icon:'📋',text:'Total properties: '+adminProps.length,time:'Now'},
    {icon:'👥',text:'Registered users: '+adminUsers.length,time:'Now'},
    {icon:'📊',text:'Total bookings: '+adminBookings.length,time:'Now'},
    {icon:'⏳',text:'Pending approvals: '+adminProps.filter(function(p){ return !p.isApproved; }).length,time:'Now'},
    {icon:'🔐',text:'Owners pending verify: '+adminUsers.filter(function(u){ return u.role==='owner'&&u.verifyStatus==='pending'; }).length,time:'Now'}
  ];
  feedEl.innerHTML=acts.map(function(a){
    return '<div style="display:flex;align-items:flex-start;gap:10px;padding:.75rem 0;border-bottom:1px solid var(--border)">'+
      '<div style="width:32px;height:32px;border-radius:50%;background:var(--surface2);display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0">'+a.icon+'</div>'+
      '<div style="flex:1"><div style="font-size:.82rem;color:var(--text);line-height:1.5">'+a.text+'</div><div style="font-size:.68rem;color:var(--text3);margin-top:2px">'+a.time+'</div></div>'+
    '</div>';
  }).join('');
}

// ── Properties table ──────────────────────────────────────
function filterPropsBy(filter, btn) {
  propFilter=filter;
  document.querySelectorAll('[id^="filter-"]').forEach(function(b){ b.classList.remove('active'); });
  if(btn) btn.classList.add('active'); renderPropsTable();
}
function renderPropsTable() {
  var tbody=document.getElementById('props-table-body'); if(!tbody) return;
  var list=propFilter==='pending'?adminProps.filter(function(p){ return !p.isApproved; }):propFilter==='approved'?adminProps.filter(function(p){ return p.isApproved; }):adminProps;
  if(!list.length){ tbody.innerHTML='<tr><td colspan="7" style="text-align:center;padding:2rem;color:var(--text3)">No properties</td></tr>'; return; }
  tbody.innerHTML=list.map(function(p){
    var ownerName=(p.owner&&p.owner.name)?p.owner.name:(typeof p.owner==='string'?'Owner':'Owner');
    var ownerEmail=(p.owner&&p.owner.email)?p.owner.email:'';
    return '<tr>'+
      '<td><div style="font-weight:600;font-size:.875rem">'+p.name+'</div><div style="font-size:.72rem;color:var(--text3)">'+p.type+'</div></td>'+
      '<td><div style="font-size:.82rem">'+ownerName+'</div><div style="font-size:.68rem;color:var(--text3)">'+ownerEmail+'</div></td>'+
      '<td>'+p.city+'</td><td style="color:var(--accent);font-weight:600">'+formatINR(p.price)+'</td><td>'+p.type+'</td>'+
      '<td><span class="badge '+(p.isApproved?'badge-approved':'badge-pending')+'">'+(p.isApproved?'Approved':'Pending')+'</span></td>'+
      '<td><div style="display:flex;gap:.4rem">'+
        (!p.isApproved?'<button class="btn btn-success btn-sm" onclick="approveProperty(\''+p._id+'\')">✅ Approve</button>':'')+
        '<button class="btn btn-danger btn-sm" onclick="removeProperty(\''+p._id+'\')">🗑️</button>'+
      '</div></td>'+
    '</tr>';
  }).join('');
}
async function approveProperty(id) {
  try { await apiFetch('/admin/properties/'+id+'/approve',{method:'PATCH'}); showToast('Property approved! ✅','success'); }
  catch(e) { showToast(e.message||'Error','error'); return; }
  var p=adminProps.filter(function(x){ return x._id===id; })[0]; if(p) p.isApproved=true;
  renderPropsTable(); renderOverviewMetrics();
}
async function removeProperty(id) {
  try { await apiFetch('/properties/'+id,{method:'DELETE'}); }
  catch(e) {}
  adminProps=adminProps.filter(function(p){ return p._id!==id; });
  renderPropsTable(); renderOverviewMetrics();
}

// ── Users table ───────────────────────────────────────────
function renderUsersTable() {
  var tbody=document.getElementById('users-table-body'); if(!tbody) return;
  if(!adminUsers.length){ tbody.innerHTML='<tr><td colspan="6" style="text-align:center;padding:2rem;color:var(--text3)">No users</td></tr>'; return; }
  tbody.innerHTML=adminUsers.map(function(u){
    var vs=u.role==='owner'?(u.verifyStatus||'unverified'):(u.isVerified?'verified':'unverified');
    var bc=vs==='verified'?'badge-approved':vs==='pending'?'badge-pending':'badge-rejected';
    var bt=vs==='verified'?'✅ Verified':vs==='pending'?'⏳ Pending':'Unverified';
    return '<tr>'+
      '<td><div style="font-weight:600;font-size:.875rem">'+u.name+'</div><div style="font-size:.68rem;color:'+(u.role==='owner'?'var(--accent)':'var(--text3)')+'">'+u.role+'</div></td>'+
      '<td style="font-size:.82rem">'+u.email+'</td>'+
      '<td><span class="badge '+(u.role==='owner'?'badge-active':'badge-pending')+'" style="font-size:.68rem">'+u.role+'</span></td>'+
      '<td style="font-size:.82rem">'+formatDate(u.createdAt)+'</td>'+
      '<td style="text-align:center">'+(u.bookings||0)+'</td>'+
      '<td><span class="badge '+bc+'">'+bt+'</span>'+
        (u.role==='owner'&&vs==='pending'?' <button class="btn btn-success btn-sm" style="margin-left:4px" onclick="verifyOwner(\''+u._id+'\')">Verify</button>':'')+
        (u.role==='owner'&&vs==='pending'?' <button class="btn btn-danger btn-sm" onclick="rejectOwnerVerify(\''+u._id+'\')">Reject</button>':'')+
      '</td>'+
    '</tr>';
  }).join('');
}
async function verifyOwner(uid) {
  try { await apiFetch('/admin/users/'+uid+'/verify',{method:'PATCH'}); showToast('Owner verified! ✅','success'); }
  catch(e){}
  var u=adminUsers.filter(function(x){ return x._id===uid; })[0]; if(u){ u.verifyStatus='verified'; u.isVerified=true; }
  renderUsersTable(); renderVerifyOwners();
}
async function rejectOwnerVerify(uid) {
  try { await apiFetch('/admin/users/'+uid+'/reject-verify',{method:'PATCH'}); }
  catch(e){}
  var u=adminUsers.filter(function(x){ return x._id===uid; })[0]; if(u){ u.verifyStatus='unverified'; }
  renderUsersTable(); renderVerifyOwners();
}

// ── Bookings table ────────────────────────────────────────
function renderBookingsTable() {
  var tbody=document.getElementById('bookings-table-body'); if(!tbody) return;
  if(!adminBookings.length){ tbody.innerHTML='<tr><td colspan="6" style="text-align:center;padding:2rem;color:var(--text3)">No bookings</td></tr>'; return; }
  tbody.innerHTML=adminBookings.map(function(b){
    var pname=(b.property&&b.property.name)||'Property'; var sname=(b.student&&b.student.name)||'Student'; var oname=(b.owner&&b.owner.name)||'Owner';
    return '<tr>'+
      '<td style="font-size:.875rem">'+sname+'</td><td style="font-size:.875rem">'+pname+'</td>'+
      '<td style="font-size:.82rem;color:var(--text3)">'+oname+'</td><td style="font-size:.82rem">'+formatDate(b.createdAt)+'</td>'+
      '<td style="color:var(--accent);font-weight:600">'+formatINR(b.monthlyRent||0)+'</td>'+
      '<td><span class="badge '+(b.status==='approved'?'badge-approved':b.status==='rejected'||b.status==='cancelled'?'badge-rejected':'badge-pending')+'">'+b.status+'</span></td>'+
    '</tr>';
  }).join('');
}

// ── Verify owners panel ───────────────────────────────────
function filterVerify(filter, btn) {
  verifyFilter=filter;
  document.querySelectorAll('[id^="vf-"]').forEach(function(b){ b.classList.remove('active'); });
  if(btn) btn.classList.add('active'); renderVerifyOwners();
}
function renderVerifyOwners() {
  var el=document.getElementById('verify-owner-list'); if(!el) return;
  var owners=adminUsers.filter(function(u){ return u.role==='owner'; });
  var list=verifyFilter==='all'?owners:owners.filter(function(u){ return (u.verifyStatus||'unverified')===verifyFilter; });
  if(!list.length){ el.innerHTML='<div class="empty-state"><div class="empty-icon">🔐</div><h3>No owners in this category</h3></div>'; return; }
  el.innerHTML=list.map(function(u){
    var vs=u.verifyStatus||'unverified';
    var bc=vs==='verified'?'badge-approved':vs==='pending'?'badge-pending':'badge-rejected';
    var bt=vs==='verified'?'✅ Verified':vs==='pending'?'⏳ Pending Review':'❌ Unverified';
    var actions=vs==='pending'?'<button class="btn btn-success btn-sm" onclick="verifyOwner(\''+u._id+'\')">✅ Approve</button> <button class="btn btn-danger btn-sm" onclick="rejectOwnerVerify(\''+u._id+'\')">✕ Reject</button>':vs==='verified'?'<button class="btn btn-danger btn-sm" onclick="rejectOwnerVerify(\''+u._id+'\')">Revoke</button>':'<span style="font-size:.72rem;color:var(--text3)">No request yet</span>';
    return '<div class="booking-card" style="margin-bottom:1rem;gap:1rem;align-items:flex-start">'+
      '<div style="width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent2));color:#0c0c10;font-weight:700;font-size:1.1rem;display:flex;align-items:center;justify-content:center;flex-shrink:0">'+initials(u.name)+'</div>'+
      '<div class="booking-info" style="flex:1">'+
        '<div class="booking-name">'+u.name+'</div>'+
        '<div class="booking-meta">📧 '+u.email+'</div>'+
        '<div class="booking-meta" style="margin-top:4px">📅 Joined: '+formatDate(u.createdAt)+'</div>'+
        '<div style="margin-top:8px"><span class="badge '+bc+'">'+bt+'</span></div>'+
      '</div>'+
      '<div style="display:flex;flex-direction:column;gap:.5rem;flex-shrink:0">'+actions+'</div>'+
    '</div>';
  }).join('');
}

// ── Charts ────────────────────────────────────────────────
function initCharts() {
  var opts={ responsive:true, maintainAspectRatio:false,
    plugins:{ legend:{ labels:{ color:'#94a3b8', font:{ size:11 } } } },
    scales:{ x:{ ticks:{ color:'#64748b' }, grid:{ color:'rgba(255,255,255,.04)' } }, y:{ ticks:{ color:'#64748b' }, grid:{ color:'rgba(255,255,255,.04)' } } } };
  var days=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  var bk=document.getElementById('bookingsChart');
  if(bk&&!charts.bookings){ charts.bookings=new Chart(bk,{ type:'line', data:{ labels:days, datasets:[{ label:'Bookings', data:[4,7,5,9,6,12,8], borderColor:'#f59e0b', backgroundColor:'rgba(245,158,11,.1)', tension:.4, fill:true, pointBackgroundColor:'#f59e0b' }] }, options:Object.assign({},opts,{ plugins:Object.assign({},opts.plugins,{ legend:{ display:false } }) }) }); }
  var cc=document.getElementById('cityChart');
  if(cc&&!charts.city){ charts.city=new Chart(cc,{ type:'doughnut', data:{ labels:['Mumbai','Delhi','Bangalore','Pune','Other'], datasets:[{ data:[28,22,18,14,18], backgroundColor:['#f59e0b','#2dd4bf','#818cf8','#fb923c','#4ade80'], borderWidth:0 }] }, options:{ responsive:true, maintainAspectRatio:false, plugins:{ legend:{ position:'right', labels:{ color:'#94a3b8', font:{ size:11 } } } } } }); }
  var tc=document.getElementById('typeChart');
  if(tc&&!charts.type){ charts.type=new Chart(tc,{ type:'bar', data:{ labels:['Hostel','PG'], datasets:[{ label:'Count', data:[adminProps.filter(function(p){ return p.type==='Hostel'; }).length||32, adminProps.filter(function(p){ return p.type==='PG'; }).length||18], backgroundColor:['#f59e0b','#2dd4bf'], borderRadius:6, borderWidth:0 }] }, options:Object.assign({},opts,{ plugins:Object.assign({},opts.plugins,{ legend:{ display:false } }) }) }); }
}
function initGrowthChart() {
  var ctx=document.getElementById('growthChart'); if(!ctx||charts.growth) return;
  charts.growth=new Chart(ctx,{ type:'line', data:{ labels:['Sep','Oct','Nov','Dec','Jan','Feb','Mar'],
    datasets:[{ label:'Users', data:[120,180,240,310,420,580,720], borderColor:'#f59e0b', backgroundColor:'rgba(245,158,11,.08)', tension:.4, fill:true, pointBackgroundColor:'#f59e0b' },
               { label:'Properties', data:[18,27,35,48,63,82,100], borderColor:'#2dd4bf', backgroundColor:'rgba(45,212,191,.08)', tension:.4, fill:true, pointBackgroundColor:'#2dd4bf' }] },
    options:{ responsive:true, maintainAspectRatio:false, plugins:{ legend:{ labels:{ color:'#94a3b8', font:{ size:11 } } } }, scales:{ x:{ ticks:{ color:'#64748b' }, grid:{ color:'rgba(255,255,255,.04)' } }, y:{ ticks:{ color:'#64748b' }, grid:{ color:'rgba(255,255,255,.04)' } } } }
  });
}
