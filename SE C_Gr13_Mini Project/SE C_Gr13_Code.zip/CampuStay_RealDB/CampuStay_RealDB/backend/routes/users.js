// ============================================================
//  CampuStay v4 — routes/users.js
// ============================================================

const express = require('express');
const router  = express.Router();
const User    = require('../models/User');
const { protect } = require('../middleware/auth');

// ── GET /api/users/profile ──────────────────────────────────
router.get('/profile', protect, (req, res) => {
  res.json({ user: req.user });
});

// ── PATCH /api/users/profile ────────────────────────────────
router.patch('/profile', protect, async (req, res) => {
  try {
    const allowed = ['name', 'phone', 'college', 'city', 'gender', 'profilePhoto', 'roommatePrefs'];
    const updates = {};
    allowed.forEach(key => { if (req.body[key] !== undefined) updates[key] = req.body[key]; });

    const user = await User.findByIdAndUpdate(req.user._id, updates, {
      new: true, runValidators: true,
    });
    res.json({ user });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// ── GET /api/users/roommates ─────────────────────────────────
// Returns students with completed roommate survey (exclude current user)
router.get('/roommates', protect, async (req, res) => {
  try {
    const { city, budget } = req.query;
    const filter = {
      role: 'student',
      isActive: true,
      'roommatePrefs.surveyDone': true,
      _id: { $ne: req.user._id },
    };
    if (city)   filter.city   = new RegExp(city, 'i');
    if (budget) filter['roommatePrefs.budget'] = budget;

    const roommates = await User.find(filter)
      .select('name college city gender roommatePrefs profilePhoto')
      .limit(20);
    res.json({ roommates });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── POST /api/users/save-property/:id ───────────────────────
router.post('/save-property/:id', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const propId = req.params.id;
    const idx = user.savedProperties.indexOf(propId);

    if (idx === -1) {
      user.savedProperties.push(propId);
    } else {
      user.savedProperties.splice(idx, 1);
    }
    await user.save();
    res.json({ saved: idx === -1, savedProperties: user.savedProperties });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
