// ============================================================
//  CampuStay v4 — models/User.js
// ============================================================

const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      maxlength: [100, 'Name cannot exceed 100 characters'],
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: [6, 'Password must be at least 6 characters'],
      select: false,
    },
    phone: { type: String, trim: true },
    role: {
      type: String,
      enum: ['student', 'owner', 'admin'],
      default: 'student',
    },

    // Student-specific
    college: { type: String, trim: true },
    city: { type: String, trim: true },
    gender: { type: String, enum: ['Male', 'Female', 'Other'] },
    profilePhoto: { type: String },

    // Roommate preferences (survey answers)
    roommatePrefs: {
      sleepTime:  { type: String },
      studyHabits:{ type: String },
      noiseLevel: { type: String },
      cleanliness:{ type: String },
      smoking:    { type: String },
      budget:     { type: String },
      genderPref: { type: String },
      surveyDone: { type: Boolean, default: false },
    },

    // Saved / bookmarked properties
    savedProperties: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Property' }],

    isVerified:   { type: Boolean, default: false },
    verifyStatus: { type: String, enum: ['unverified','pending','verified'], default: 'unverified' },
    isActive:   { type: Boolean, default: true },
  },
  { timestamps: true }
);

// Hash password before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Compare password
userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Remove sensitive fields from JSON output
userSchema.methods.toJSON = function () {
  const obj = this.toObject();
  delete obj.password;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
