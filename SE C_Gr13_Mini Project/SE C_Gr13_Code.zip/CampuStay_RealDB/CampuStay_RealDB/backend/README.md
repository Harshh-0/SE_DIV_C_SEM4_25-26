# ⚙️ CampuStay — Backend

Node.js + Express REST API with MongoDB.

---

## Quick Start

```bash
cd backend
npm install
cp .env.example .env   # fill in your values
node seed.js           # populate demo data
npm run dev            # start with auto-restart
```

Server runs at `http://localhost:5000`

---

## Architecture

```
backend/
├── server.js          # Express app, DB connection, route mounting
├── seed.js            # One-time demo data population
├── package.json       # Dependencies and npm scripts
├── .env.example       # Environment variable template
│
├── controllers/       # Business logic (no Express in here)
│   ├── authController.js
│   ├── propertyController.js
│   ├── bookingController.js
│   └── adminController.js
│
├── models/            # Mongoose schemas
│   ├── User.js
│   ├── Property.js
│   ├── Booking.js
│   └── Message.js
│
├── routes/            # Express routers (thin — just map URLs to controllers)
│   ├── auth.js        # /api/auth/*
│   ├── properties.js  # /api/properties/*
│   ├── bookings.js    # /api/bookings/*
│   ├── admin.js       # /api/admin/*
│   └── users.js       # /api/users/*
│
└── middleware/
    ├── auth.js        # protect (JWT verify) + authorize (role check)
    └── errorHandler.js # Global Express error handler
```

---

## API Endpoint Summary

```
POST   /api/auth/register
POST   /api/auth/login
GET    /api/auth/me                    🔒

GET    /api/properties                 (filters: city, type, gender, price)
GET    /api/properties/:id
POST   /api/properties                 🔒 owner
PATCH  /api/properties/:id             🔒 owner
DELETE /api/properties/:id             🔒 owner/admin
GET    /api/properties/owner/mine      🔒 owner
POST   /api/properties/:id/review      🔒 student

POST   /api/bookings                   🔒 student
GET    /api/bookings/my                🔒 student
GET    /api/bookings/owner             🔒 owner
PATCH  /api/bookings/:id/status        🔒
GET    /api/bookings/admin/all         🔒 admin

GET    /api/users/profile              🔒
PATCH  /api/users/profile              🔒
GET    /api/users/roommates            🔒 student
POST   /api/users/save-property/:id    🔒 student

GET    /api/admin/stats                🔒 admin
GET    /api/admin/users                🔒 admin
PATCH  /api/admin/users/:id/status     🔒 admin
GET    /api/admin/properties/pending   🔒 admin
PATCH  /api/admin/properties/:id/approve 🔒 admin
DELETE /api/admin/properties/:id       🔒 admin
```

Full details in `../docs/API.md`.

---

## npm Scripts

| Script | Command | Description |
|---|---|---|
| `start` | `node server.js` | Production start |
| `dev` | `nodemon server.js` | Dev with auto-restart |
| `seed` | `node seed.js` | Seed demo data |
| `test` | `jest --coverage` | Run tests |

---

## Environment Variables

Copy `.env.example` to `.env` and fill in:

| Key | Required | Default | Description |
|---|---|---|---|
| `PORT` | No | `5000` | Server port |
| `MONGO_URI` | **Yes** | — | MongoDB connection string |
| `JWT_SECRET` | **Yes** | — | Long random string for JWT |
| `JWT_EXPIRES_IN` | No | `7d` | Token lifetime |
| `NODE_ENV` | No | `development` | Environment flag |

---

## Demo Credentials (after seeding)

| Role | Email | Password |
|---|---|---|
| Student | ananya@student.com | demo123 |
| Owner | priya@owner.com | demo123 |
| Admin | admin@campustay.com | demo123 |
