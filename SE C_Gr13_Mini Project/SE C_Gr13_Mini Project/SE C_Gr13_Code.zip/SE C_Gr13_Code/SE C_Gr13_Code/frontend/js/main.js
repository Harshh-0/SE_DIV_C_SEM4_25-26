// ============================================================
//  CampuStay — main.js  (real API integration)
// ============================================================

var API = 'http://localhost:5000/api';

// ── Auth helpers ──────────────────────────────────────────
function getUser()  { try { return JSON.parse(localStorage.getItem('cs_user')); } catch(e){ return null; } }
function getToken() { return localStorage.getItem('cs_token') || ''; }
function isDemo()   { return getToken().startsWith('demo_'); }

function saveAuth(token, user) {
  localStorage.setItem('cs_token', token);
  localStorage.setItem('cs_user', JSON.stringify(user));
}

function logout() {
  localStorage.removeItem('cs_token');
  localStorage.removeItem('cs_user');
  window.location.href = '../index.html';
}

function requireAuth(role) {
  var user = getUser(); var token = getToken();
  if (!user || !token) { window.location.href = 'login.html'; return false; }
  if (role && user.role !== role) {
    var map = { student:'student-dashboard.html', owner:'owner-dashboard.html', admin:'admin-dashboard.html' };
    window.location.href = map[user.role] || 'login.html';
    return false;
  }
  return true;
}

// ── API fetch (always tries real backend) ─────────────────
async function apiFetch(path, opts) {
  opts = opts || {};
  var token = getToken();
  var headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
  if (token) headers['Authorization'] = 'Bearer ' + token;
  var res = await fetch(API + path, Object.assign({}, opts, { headers: headers }));
  var data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Request failed (' + res.status + ')');
  return data;
}

// ── Toast ─────────────────────────────────────────────────
function showToast(msg, type) {
  var t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.className = 'toast' + (type ? ' toast-' + type : '');
  t.classList.add('show');
  clearTimeout(t._tid);
  t._tid = setTimeout(function(){ t.classList.remove('show'); }, 3200);
}

// ── Dropdown ──────────────────────────────────────────────
function toggleDropdown(id) {
  var el = document.getElementById(id);
  if (!el) return;
  var open = el.classList.contains('open');
  document.querySelectorAll('.dropdown-menu.open').forEach(function(d){ d.classList.remove('open'); });
  if (!open) el.classList.add('open');
}
document.addEventListener('click', function(e) {
  if (!e.target.closest('.avatar') && !e.target.closest('.dropdown-menu'))
    document.querySelectorAll('.dropdown-menu.open').forEach(function(d){ d.classList.remove('open'); });
});

// ── Populate nav user ─────────────────────────────────────
function getUserAvatarKey() {
  var user = getUser();
  return user && user._id ? 'cs_avatar_' + user._id : null;
}

function getUserAvatar() {
  var key = getUserAvatarKey();
  return key ? localStorage.getItem(key) : null;
}

function saveUserAvatar(dataUrl) {
  var key = getUserAvatarKey();
  if (key) localStorage.setItem(key, dataUrl);
}

function populateNavUser() {
  var user = getUser(); if (!user) return;
  var av = document.getElementById('user-avatar');
  if (av) {
    var avatar = getUserAvatar();
    if (avatar) {
      av.style.overflow = 'hidden';
      av.style.padding = '0';
      // Clear text node
      for (var i = 0; i < av.childNodes.length; i++) {
        if (av.childNodes[i].nodeType === 3) { av.childNodes[i].textContent = ''; break; }
      }
      // Insert/update img
      var img = av.querySelector('img.nav-avatar-img');
      if (!img) {
        img = document.createElement('img');
        img.className = 'nav-avatar-img';
        img.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:50%;position:absolute;top:0;left:0';
        av.style.position = 'relative';
        av.appendChild(img);
      }
      img.src = avatar;
    } else {
      // Remove stale img, restore initials
      var stale = av.querySelector('img.nav-avatar-img');
      if (stale) stale.remove();
      for (var j = 0; j < av.childNodes.length; j++) {
        if (av.childNodes[j].nodeType === 3) { av.childNodes[j].textContent = initials(user.name || 'U'); break; }
      }
    }
  }
  var nm = document.getElementById('user-name-display');
  if (nm) nm.textContent = user.name || 'User';
}

// ── Helpers ───────────────────────────────────────────────
function initials(name) {
  if (!name) return '?';
  return name.split(' ').map(function(p){ return p[0]; }).join('').toUpperCase().slice(0,2);
}
function formatINR(n) {
  if (!n && n !== 0) return '₹0';
  return '₹' + Number(n).toLocaleString('en-IN');
}
function formatDate(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
}

// ── Reveal on scroll ──────────────────────────────────────
var revealObs = new IntersectionObserver(function(entries){
  entries.forEach(function(e){ if(e.isIntersecting){ e.target.classList.add('revealed'); revealObs.unobserve(e.target); } });
},{ threshold:0.1 });
document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('.reveal').forEach(function(el){ revealObs.observe(el); });
});
