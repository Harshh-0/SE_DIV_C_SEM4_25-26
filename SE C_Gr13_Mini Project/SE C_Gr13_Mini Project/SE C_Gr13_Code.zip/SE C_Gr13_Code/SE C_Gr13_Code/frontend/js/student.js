// ============================================================
//  CampuStay — student.js  (real API + demo fallback)
// ============================================================

var FALLBACK_PROPS = [
  { _id:'p1', name:'Sunrise Boys Hostel', city:'Pune',      address:'Koregaon Park', price:8500,  type:'Hostel', gender:'Boys',  photos:['https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=600&q=80'], amenities:['WiFi','Meals','Laundry','Hot Water'], roomsAvailable:4, avgRating:4.7, totalReviews:48, owner:{ name:'Priya Nair' },  description:'Spacious hostel near Pune University.', isApproved:true },
  { _id:'p2', name:'Green Leaf PG',       city:'Bangalore', address:'Koramangala',   price:12000, type:'PG',     gender:'Girls', photos:['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=600&q=80'], amenities:['WiFi','AC','Meals','Security'],        roomsAvailable:2, avgRating:4.9, totalReviews:76, owner:{ name:'Meera Iyer' }, description:'Premium girls PG in Koramangala.', isApproved:true },
  { _id:'p3', name:"Scholar's Den",       city:'Delhi',     address:'Lajpat Nagar',  price:7500,  type:'Hostel', gender:'Boys',  photos:['https://images.unsplash.com/photo-1560448204-603b3fc33ddc?w=600&q=80'], amenities:['WiFi','Study Room','Meals'],           roomsAvailable:8, avgRating:4.5, totalReviews:32, owner:{ name:'Arjun Mehta' },description:"Budget hostel with study rooms.", isApproved:true },
  { _id:'p4', name:'Campus View PG',      city:'Mumbai',    address:'Andheri West',  price:10000, type:'PG',     gender:'Both',  photos:['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=600&q=80'], amenities:['WiFi','AC','Gym','Parking'],           roomsAvailable:3, avgRating:4.6, totalReviews:55, owner:{ name:'Sanjay Patel' },description:'Modern PG near colleges.', isApproved:true },
  { _id:'p5', name:'Vidyarthi Niwas',     city:'Hyderabad', address:'Madhapur',      price:6500,  type:'Hostel', gender:'Boys',  photos:['https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=600&q=80'], amenities:['WiFi','Meals','Security'],             roomsAvailable:12,avgRating:4.3, totalReviews:29, owner:{ name:'Ramesh K.' },  description:'Affordable hostel near HITEC City.', isApproved:true },
  { _id:'p6', name:'Lotus Girls Hostel',  city:'Chennai',   address:'T. Nagar',      price:9000,  type:'Hostel', gender:'Girls', photos:['https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=600&q=80'], amenities:['WiFi','Meals','CCTV','Laundry'],       roomsAvailable:5, avgRating:4.8, totalReviews:61, owner:{ name:'Kavitha R.' }, description:'Safe girls hostel in Chennai.', isApproved:true }
];

var MOCK_ROOMMATES = [
  { name:'Karan M.', college:'IIT Delhi',       year:'3rd Year', score:94, sleep:'10 PM–12 AM', budget:'₹6k–10k',  hobbies:['Gaming','Music','Coding'] },
  { name:'Dev S.',   college:'Delhi University', year:'2nd Year', score:88, sleep:'12–2 AM',     budget:'₹6k–10k',  hobbies:['Cricket','Reading'] },
  { name:'Arjun P.', college:'NIT Delhi',        year:'1st Year', score:82, sleep:'Before 10 PM',budget:'₹10k–15k', hobbies:['Gym','Movies'] },
  { name:'Rohan T.', college:'IGNOU',            year:'2nd Year', score:76, sleep:'After 2 AM',  budget:'Under ₹6k', hobbies:['Music','Photography'] }
];

var RM_QUESTIONS = [
  { q:'What time do you usually wake up?',  options:['Before 6 AM 🌅','6–8 AM ☀️','8–10 AM 😴','After 10 AM 🌙'], key:'wake' },
  { q:'When do you usually go to sleep?',  options:['Before 10 PM 🌙','10 PM–12 AM 🌜','12–2 AM 🌚','After 2 AM 👻'],key:'sleep' },
  { q:'How do you prefer to study?',        options:['Silence 🤫','Soft music 🎵','In a group 👥','Anywhere 🤷'],       key:'study' },
  { q:'Your ideal cleanliness level?',      options:['Very tidy 🧹','Reasonably clean 😊','Casual 😅','No preference 🤷'],key:'clean' },
  { q:'How often do you have guests over?', options:['Never 🚫','Rarely 😊','Sometimes 🤝','Frequently 🎉'],           key:'guests' },
  { q:'Your monthly housing budget?',       options:['Under ₹6k 💰','₹6k–10k 💵','₹10k–15k 💳','Above ₹15k 🏦'],      key:'budget' },
  { q:'Preferred gender of roommates?',     options:['Same gender 🚻','Mixed 🤝','No preference 😊'],                   key:'gender' }
];

var AUTO_REPLIES = [
  "Thanks for your message! I'll get back to you shortly.",
  "The room is available for viewing between 10 AM and 6 PM.",
  "Please share your college ID for the booking process.",
  "The rent includes WiFi and utilities. Meals are optional.",
  "2 months security deposit required, fully refundable."
];

// ── State ─────────────────────────────────────────────────
var allProperties      = [];
var filteredProperties = [];
var myBookings         = [];
var savedIds           = JSON.parse(localStorage.getItem('cs_saved') || '[]');
var chatContacts       = [];
var currentChatId      = null;
var chatOpen           = false;
var leafletMap         = null;
var rmAnswers          = {};

// ── Init ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  if (!requireAuth('student')) return;
  populateNavUser();
  var user = getUser();
  if (user) { var ed=document.getElementById('user-email-display'); if(ed) ed.textContent=user.email||''; }
  loadProperties();
  loadBookings();
  renderNotifications();
  updateChatBadge();
  switchTab('home');
});

// ── Load properties from API ──────────────────────────────
async function loadProperties() {
  try {
    var data = await apiFetch('/properties?approved=true&limit=50');
    allProperties = data.properties || [];
  } catch(e) {
    allProperties = FALLBACK_PROPS;
  }
  filteredProperties = allProperties.slice();
  renderProperties();
  renderHomeStats();
}

// ── Load bookings from API ────────────────────────────────
async function loadBookings() {
  try {
    var data = await apiFetch('/bookings/my');
    myBookings = data.bookings || [];
  } catch(e) {
    myBookings = [];
  }
  renderBookings();
  renderHomeStats();
}

// ── Tab switching ─────────────────────────────────────────
window.switchTab = function(id) {
  document.querySelectorAll('[id^="tab-"]').forEach(function(t){ t.style.display='none'; });
  var panel=document.getElementById('tab-'+id); if(panel) panel.style.display='';
  document.querySelectorAll('[id^="snav-"]').forEach(function(a){ a.classList.remove('active'); });
  var nav=document.getElementById('snav-'+id); if(nav) nav.classList.add('active');
  document.querySelectorAll('.sidebar-item[data-tab]').forEach(function(s){ s.classList.toggle('active',s.dataset.tab===id); });
  if (id==='home')     renderHomeStats();
  if (id==='browse')   { renderProperties(); setTimeout(initMap,200); }
  if (id==='bookings') renderBookings();
};

// ── Home stats ────────────────────────────────────────────
function renderHomeStats() {
  var approved=myBookings.filter(function(b){ return b.status==='approved'; }).length;
  var pending =myBookings.filter(function(b){ return b.status==='pending';  }).length;
  var user=getUser();
  var h=new Date().getHours();
  var greet=h<12?'Good morning':h<17?'Good afternoon':'Good evening';
  var wm=document.getElementById('welcome-msg');
  if(wm) wm.textContent=greet+(user?', '+user.name.split(' ')[0]+'! 👋':'! 👋');
  [['stat-bookings',approved+pending],['stat-active-bookings',approved],['stat-pending',pending],['stat-saved',savedIds.length]].forEach(function(p){
    var el=document.getElementById(p[0]); if(el) el.textContent=p[1];
  });
  var feat=document.getElementById('featured-properties');
  if(feat){ feat.innerHTML=allProperties.slice(0,4).map(buildPropCard).join(''); fixBrokenImages(); }
  var rmEl=document.getElementById('home-roommates');
  if(rmEl) rmEl.innerHTML=MOCK_ROOMMATES.slice(0,3).map(function(m){
    var c=m.score>=90?'var(--green)':m.score>=80?'var(--accent)':'var(--text2)';
    return '<div class="card" style="display:flex;align-items:center;gap:12px;padding:.9rem 1.1rem">'+
      '<div style="width:42px;height:42px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent2));color:#0c0c10;font-weight:700;font-size:.95rem;display:flex;align-items:center;justify-content:center">'+m.name[0]+'</div>'+
      '<div style="flex:1"><div style="font-weight:600;font-size:.875rem">'+m.name+'</div><div style="font-size:.72rem;color:var(--text3)">'+m.college+' · '+m.year+'</div></div>'+
      '<div style="text-align:right"><div style="font-family:\'Clash Display\',sans-serif;font-size:1.1rem;font-weight:700;color:'+c+'">'+m.score+'%</div><div style="font-size:.62rem;color:var(--text3)">match</div></div>'+
    '</div>';
  }).join('');
}

// ── Property card builder ─────────────────────────────────
function getPropImg(p) { return (p.photos && p.photos[0]) ? p.photos[0] : ''; }
function getPropEmoji(p) { return p.emoji || (p.type==='PG'?'🏠':'🏢'); }
function getPropOwnerName(p) { return (p.owner && p.owner.name) ? p.owner.name : 'Owner'; }

function buildPropCard(p) {
  var saved = savedIds.indexOf(p._id) !== -1;
  var img   = getPropImg(p);
  var emoji = getPropEmoji(p);
  var chips = (p.amenities||[]).slice(0,4).map(function(a){ return '<span class="prop-amenity-chip">'+a+'</span>'; }).join('');
  var stars = '';
  for(var i=0;i<Math.floor(p.avgRating||0);i++) stars+='★';
  var imgHtml = img
    ? '<img id="pi_'+p._id+'" class="prop-img" src="'+img+'" alt="'+p.name+'" style="display:block"/><div class="prop-img-fallback" id="pf_'+p._id+'" style="display:none">'+emoji+'</div>'
    : '<div class="prop-img-fallback">'+emoji+'</div>';
  return '<div class="prop-card" onclick="openPropertyModal(\''+p._id+'\')">'+
    '<div class="prop-img-wrap">'+imgHtml+
      '<div class="prop-img-overlay"></div>'+
      '<div class="prop-top-badges">'+
        '<span class="prop-badge prop-badge-type">'+p.type+' · '+p.gender+'</span>'+
        ((p.avgRating||0)>=4.7?'<span class="prop-badge prop-badge-green">⭐ Top Rated</span>':'')+
      '</div>'+
      '<div class="prop-price-pill">'+formatINR(p.price)+'/mo</div>'+
      '<div class="prop-save'+(saved?' saved':'')+'" onclick="event.stopPropagation();toggleSave(\''+p._id+'\',this)">'+(saved?'❤️':'🤍')+'</div>'+
    '</div>'+
    '<div class="prop-body">'+
      '<div class="prop-name">'+p.name+'</div>'+
      '<div class="prop-loc">📍 '+p.address+', '+p.city+'</div>'+
      '<div style="display:flex;align-items:center;gap:6px;margin-bottom:.6rem">'+
        '<span style="color:#f59e0b;font-size:.75rem">'+stars+'</span>'+
        '<span style="font-size:.72rem;font-weight:700;color:var(--text2)">'+(p.avgRating||'–')+'</span>'+
        '<span style="font-size:.68rem;color:var(--text3)">('+( p.totalReviews||0)+' reviews)</span>'+
        '<span style="margin-left:auto;font-size:.68rem;color:var(--green);font-weight:600">'+(p.roomsAvailable||0)+' left</span>'+
      '</div>'+
      '<div class="prop-amenity-row">'+chips+'</div>'+
      '<div class="prop-card-footer">'+
        '<div class="prop-owner-av">'+initials(getPropOwnerName(p))+'</div>'+
        '<div class="prop-owner-info"><div class="prop-owner-name">'+getPropOwnerName(p)+'</div><div class="prop-rooms-left">Property Owner</div></div>'+
        '<button class="prop-view-btn">View →</button>'+
      '</div>'+
    '</div>'+
  '</div>';
}

function fixBrokenImages() {
  allProperties.forEach(function(p) {
    var img=document.getElementById('pi_'+p._id);
    if(!img) return;
    img.onerror=function(){ img.style.display='none'; var fb=document.getElementById('pf_'+p._id); if(fb) fb.style.display='flex'; };
  });
}

function renderProperties() {
  var grid=document.getElementById('all-properties')||document.getElementById('prop-grid');
  if(!grid) return;
  if(!filteredProperties.length){
    grid.innerHTML='<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">🔍</div><h3>No properties found</h3><p>Try adjusting your filters</p></div>';
    return;
  }
  grid.innerHTML=filteredProperties.map(buildPropCard).join('');
  var cnt=document.getElementById('prop-count'); if(cnt) cnt.textContent=filteredProperties.length+' properties';
  setTimeout(fixBrokenImages,50);
}

function filterProperties() {
  var city=((document.getElementById('search-loc')||{}).value||'').trim().toLowerCase();
  var type=((document.getElementById('search-type')||{}).value||'');
  var gend=((document.getElementById('search-gender')||{}).value||'');
  var maxP=parseInt(((document.getElementById('search-price')||{}).value||''))||999999;
  filteredProperties=allProperties.filter(function(p){
    if(city && p.city.toLowerCase().indexOf(city)===-1 && p.address.toLowerCase().indexOf(city)===-1) return false;
    if(type && p.type!==type) return false;
    if(gend && gend!=='Both' && p.gender!==gend && p.gender!=='Both') return false;
    if(p.price>maxP) return false;
    return true;
  });
  renderProperties();
  showToast('Showing '+filteredProperties.length+' properties','');
}

async function toggleSave(id, el) {
  var idx=savedIds.indexOf(id);
  if(idx!==-1){ savedIds.splice(idx,1); el.classList.remove('saved'); el.textContent='🤍'; showToast('Removed from saved',''); }
  else { savedIds.push(id); el.classList.add('saved'); el.textContent='❤️'; showToast('Property saved! ❤️','success'); }
  localStorage.setItem('cs_saved',JSON.stringify(savedIds));
  try { await apiFetch('/users/save-property/'+id,{method:'POST'}); } catch(e){}
}

// ── Property modal ────────────────────────────────────────
function openPropertyModal(id) {
  var p=allProperties.filter(function(x){ return x._id===id; })[0]; if(!p) return;
  var modal=document.getElementById('propertyModal')||document.getElementById('propModal'); if(!modal) return;
  function set(elId,val){ var el=document.getElementById(elId); if(el) el.textContent=val; }
  set('m-name',p.name); set('m-loc','📍 '+p.address+', '+p.city);
  set('m-price',formatINR(p.price)+'/mo'); set('m-type',p.type);
  set('m-gender',p.gender); set('m-rooms',(p.roomsAvailable||0)+' rooms left');
  set('m-desc',p.description||''); set('m-owner-name',getPropOwnerName(p));
  set('m-owner-av',initials(getPropOwnerName(p)));
  var emojiEl=document.getElementById('m-emoji');
  if(emojiEl){ emojiEl.textContent=getPropEmoji(p); emojiEl.style.display='flex'; }
  var photoEl=document.getElementById('m-photo');
  if(photoEl && getPropImg(p)){
    photoEl.src=getPropImg(p); photoEl.style.display='block';
    photoEl.onerror=function(){ photoEl.style.display='none'; if(emojiEl) emojiEl.style.display='flex'; };
  } else if(photoEl){ photoEl.style.display='none'; }
  var am=document.getElementById('m-amenities');
  if(am) am.innerHTML=(p.amenities||[]).map(function(a){ return '<span class="amenity-chip">'+a+'</span>'; }).join('');
  var bookBtn=document.getElementById('modal-book-btn');
  if(bookBtn) bookBtn.onclick=function(){ closeModal(); bookProperty(id); };
  var msgBtn=document.getElementById('modal-msg-btn');
  if(msgBtn) msgBtn.onclick=function(){ closeModal(); openOwnerChat(getPropOwnerName(p),p); };
  modal.classList.remove('hidden');
}
function closeModal(){ ['propertyModal','propModal','mapModal'].forEach(function(id){ var m=document.getElementById(id); if(m) m.classList.add('hidden'); }); }
function closeMapModal(){ closeModal(); }
function openPropertyMap(){ showToast('View on map — check the Browse tab',''); }

// ── Booking ───────────────────────────────────────────────
async function bookProperty(id) {
  var p=allProperties.filter(function(x){ return x._id===id; })[0]; if(!p) return;
  var exists=myBookings.filter(function(b){ return (b.property&&(b.property._id||b.property)===id)&&(b.status==='pending'||b.status==='approved'); }).length>0;
  if(exists){ showToast('You already have an active request for this property','error'); return; }

  try {
    var data=await apiFetch('/bookings',{method:'POST',body:JSON.stringify({propertyId:id})});
    myBookings.unshift(data.booking);
    showToast('Booking request sent! 🎉','success');
  } catch(err) {
    // Demo fallback
    myBookings.unshift({_id:'b'+Date.now(),property:p,status:'pending',createdAt:new Date().toISOString(),monthlyRent:p.price});
    showToast('Request sent (demo mode) 🎉','success');
  }
  renderBookings(); renderHomeStats();
}

async function cancelBooking(id) {
  try { await apiFetch('/bookings/'+id+'/status',{method:'PATCH',body:JSON.stringify({status:'cancelled'})}); }
  catch(e){}
  myBookings=myBookings.map(function(b){ return b._id===id?Object.assign({},b,{status:'cancelled'}):b; });
  showToast('Booking cancelled',''); renderBookings(); renderHomeStats();
}

function openOwnerChatById(propId) {
  var b=myBookings.filter(function(x){ return (x.property&&(x.property._id||x.property)===propId)||(x.propertyId===propId); })[0];
  var ownerName=b&&b.property&&b.property.owner?b.property.owner.name||'Owner':'Owner';
  openOwnerChat(ownerName,b&&b.property?b.property:null);
}

function renderBookings() {
  var el=document.getElementById('booking-list'); if(!el) return;
  if(!myBookings.length){
    el.innerHTML='<div class="empty-state"><div class="empty-icon">🏠</div><h3>No bookings yet</h3><p>Browse properties and send a request.</p><button class="btn btn-primary" style="margin-top:1.25rem" onclick="switchTab(\'browse\')">Browse Properties →</button></div>';
    return;
  }
  var approved=myBookings.filter(function(b){ return b.status==='approved'; }).length;
  var pending =myBookings.filter(function(b){ return b.status==='pending';  }).length;
  var rejected=myBookings.filter(function(b){ return b.status==='rejected'||b.status==='cancelled'; }).length;
  var summary='<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:2rem">'+
    '<div style="background:rgba(74,222,128,.06);border:1px solid rgba(74,222,128,.18);border-radius:14px;padding:1.1rem;text-align:center"><div style="font-size:1.6rem;font-weight:800;color:var(--green)">'+approved+'</div><div style="font-size:.72rem;color:var(--text3);margin-top:3px;font-weight:600;text-transform:uppercase;letter-spacing:.06em">Approved</div></div>'+
    '<div style="background:rgba(245,158,11,.06);border:1px solid rgba(245,158,11,.18);border-radius:14px;padding:1.1rem;text-align:center"><div style="font-size:1.6rem;font-weight:800;color:var(--accent)">'+pending+'</div><div style="font-size:.72rem;color:var(--text3);margin-top:3px;font-weight:600;text-transform:uppercase;letter-spacing:.06em">Pending</div></div>'+
    '<div style="background:rgba(251,113,133,.06);border:1px solid rgba(251,113,133,.18);border-radius:14px;padding:1.1rem;text-align:center"><div style="font-size:1.6rem;font-weight:800;color:var(--rose)">'+rejected+'</div><div style="font-size:.72rem;color:var(--text3);margin-top:3px;font-weight:600;text-transform:uppercase;letter-spacing:.06em">Declined</div></div>'+
  '</div>';
  var cards=myBookings.map(function(b){
    var p=b.property||{}; var propId=(p._id||b.propertyId||'');
    var stColor=b.status==='approved'?'var(--green)':b.status==='rejected'||b.status==='cancelled'?'var(--rose)':'var(--accent)';
    var stBg=b.status==='approved'?'rgba(74,222,128,.06)':b.status==='rejected'||b.status==='cancelled'?'rgba(251,113,133,.06)':'rgba(245,158,11,.06)';
    var stBorder=b.status==='approved'?'rgba(74,222,128,.2)':b.status==='rejected'||b.status==='cancelled'?'rgba(251,113,133,.2)':'rgba(245,158,11,.2)';
    var stLabel=b.status==='approved'?'✅ Approved':b.status==='rejected'||b.status==='cancelled'?'✕ Declined':'⏳ Pending Review';
    var stDesc=b.status==='approved'?'Booking confirmed. Contact the owner to arrange move-in.':b.status==='rejected'||b.status==='cancelled'?'Request declined. Try another property.':'Waiting for the owner to review your request.';
    var img=getPropImg(p); var emoji=getPropEmoji(p);
    var imgHtml=img?'<div style="width:110px;min-height:110px;border-radius:12px;overflow:hidden;flex-shrink:0"><img src="'+img+'" style="width:100%;height:100%;object-fit:cover" alt=""/></div>':'<div style="width:110px;min-height:110px;border-radius:12px;background:var(--surface2);display:flex;align-items:center;justify-content:center;font-size:3rem;flex-shrink:0">'+emoji+'</div>';
    var chips=(p.amenities||[]).slice(0,3).map(function(a){ return '<span style="font-size:.65rem;padding:2px 7px;border-radius:100px;background:var(--surface2);border:1px solid var(--border);color:var(--text3)">'+a+'</span>'; }).join('');
    var actions=b.status==='approved'?'<button class="btn btn-primary btn-sm" style="justify-content:center;width:100%" onclick="openOwnerChatById(\''+propId+'\')">💬 Message</button>':b.status==='pending'?'<button class="btn btn-ghost btn-sm" style="justify-content:center;width:100%;color:var(--rose)" onclick="cancelBooking(\''+b._id+'\')">Cancel</button>':'<button class="btn btn-outline btn-sm" style="justify-content:center;width:100%" onclick="switchTab(\'browse\')">Find Another</button>';
    return '<div style="background:var(--surface);border:1px solid var(--border);border-radius:18px;overflow:hidden;margin-bottom:1.25rem">'+
      '<div style="padding:.55rem 1.25rem;background:'+stBg+';border-bottom:1px solid '+stBorder+';display:flex;align-items:center;justify-content:space-between">'+
        '<div style="display:flex;align-items:center;gap:7px"><div style="width:7px;height:7px;border-radius:50%;background:'+stColor+'"></div><span style="font-size:.75rem;font-weight:700;color:'+stColor+'">'+stLabel+'</span></div>'+
        '<span style="font-size:.68rem;color:var(--text3)">Applied '+formatDate(b.createdAt)+'</span>'+
      '</div>'+
      '<div style="display:flex;gap:1.25rem;padding:1.25rem;align-items:flex-start">'+
        imgHtml+
        '<div style="flex:1;min-width:0">'+
          '<div style="font-family:\'Clash Display\',sans-serif;font-size:1.05rem;font-weight:700;margin-bottom:3px">'+(p.name||'Property')+'</div>'+
          '<div style="font-size:.75rem;color:var(--text3);margin-bottom:.5rem">📍 '+(p.address||'')+', '+(p.city||'')+'</div>'+
          '<div style="display:flex;flex-wrap:wrap;gap:.3rem;margin-bottom:.6rem">'+chips+'</div>'+
          '<div style="font-size:.75rem;color:var(--text3)">'+stDesc+'</div>'+
        '</div>'+
        '<div style="display:flex;flex-direction:column;align-items:flex-end;flex-shrink:0;min-width:105px">'+
          '<div style="text-align:right"><div style="font-family:\'Clash Display\',sans-serif;font-size:1.3rem;font-weight:800;color:var(--accent)">'+formatINR(b.monthlyRent||p.price||0)+'</div><div style="font-size:.65rem;color:var(--text3)">per month</div></div>'+
          '<div style="margin-top:.75rem;width:100%">'+actions+'</div>'+
        '</div>'+
      '</div>'+
    '</div>';
  }).join('');
  el.innerHTML=summary+cards;
}

// ── Chat ──────────────────────────────────────────────────
function toggleChat() {
  chatOpen=!chatOpen;
  var win=document.getElementById('chatWindow'); if(!win) return;
  if(chatOpen){ win.classList.add('open'); var b=document.getElementById('chatBadge'); if(b) b.style.display='none'; renderChatContacts(); if(currentChatId) renderChatMessages(currentChatId); }
  else win.classList.remove('open');
}
function updateChatBadge() {
  var total=chatContacts.reduce(function(n,c){ return n+(c.unread||0); },0);
  var b=document.getElementById('chatBadge'); if(!b) return;
  b.textContent=total; b.style.display=total>0?'flex':'none';
}
function renderChatContacts() {
  var el=document.getElementById('chat-contacts'); if(!el) return;
  if(!chatContacts.length){ el.innerHTML='<div style="padding:1rem;text-align:center;font-size:.78rem;color:var(--text3)">No conversations yet.<br>Message a property owner to start!</div>'; return; }
  el.innerHTML=chatContacts.map(function(c){
    var last=c.messages[c.messages.length-1];
    var preview=last?last.text.slice(0,28)+(last.text.length>28?'…':''):'';
    return '<div class="chat-contact'+(currentChatId===c.id?' active':'')+'" onclick="selectChatContact(\''+c.id+'\')">'+
      '<div class="chat-contact-av" style="background:'+c.color+'">'+c.avatar+'</div>'+
      '<div class="chat-contact-meta"><div class="chat-contact-name">'+c.name+'</div><div class="chat-contact-last">'+preview+'</div></div>'+
      (c.unread>0?'<div class="chat-contact-unread">'+c.unread+'</div>':'')+
    '</div>';
  }).join('');
}
function selectChatContact(id) {
  currentChatId=id;
  var c=chatContacts.filter(function(x){ return x.id===id; })[0]; if(!c) return;
  c.unread=0; updateChatBadge();
  var av=document.getElementById('chat-av'); if(av){ av.textContent=c.avatar; av.style.background=c.color; }
  var nm=document.getElementById('chat-name'); if(nm) nm.textContent=c.name;
  renderChatContacts(); renderChatMessages(id);
}
function renderChatMessages(cid) {
  var c=chatContacts.filter(function(x){ return x.id===cid; })[0];
  var el=document.getElementById('chat-messages'); if(!el||!c) return;
  el.innerHTML=c.messages.map(function(m){
    return '<div class="chat-msg '+(m.from==='me'?'me':'them')+'"><div class="chat-bubble">'+m.text+'</div><div class="chat-time">'+m.time+'</div></div>';
  }).join('');
  el.scrollTop=el.scrollHeight;
}
function sendMessage() {
  var input=document.getElementById('chat-input'); if(!input||!input.value.trim()||!currentChatId) return;
  var text=input.value.trim(); input.value='';
  var c=chatContacts.filter(function(x){ return x.id===currentChatId; })[0]; if(!c) return;
  var now=new Date(); var time=now.getHours()+':'+String(now.getMinutes()).padStart(2,'0');
  c.messages.push({id:'m'+Date.now(),from:'me',text:text,time:time}); renderChatMessages(currentChatId);
  setTimeout(function(){
    c.messages.push({id:'m'+Date.now(),from:'them',text:AUTO_REPLIES[Math.floor(Math.random()*AUTO_REPLIES.length)],time:time});
    renderChatMessages(currentChatId); if(!chatOpen){ c.unread++; updateChatBadge(); }
  },1200+Math.random()*800);
}
function openOwnerChat(ownerName,property) {
  var c=chatContacts.filter(function(x){ return x.name===ownerName; })[0];
  if(!c){
    c={id:'oc'+Date.now(),name:ownerName,role:'Owner',avatar:initials(ownerName),color:'#f59e0b',unread:0,
      messages:[{id:'m'+Date.now(),from:'them',text:"Hi! I'm "+ownerName+", owner of "+(property?property.name:'the property')+". How can I help?",time:'Now'}]};
    chatContacts.unshift(c);
  }
  chatOpen=true; var win=document.getElementById('chatWindow'); if(win) win.classList.add('open');
  selectChatContact(c.id);
}

// ── Notifications ─────────────────────────────────────────
function renderNotifications() {
  var el=document.getElementById('notif-list'); if(!el) return;
  var notifs=[
    {type:'booking',icon:'🏠',text:'Welcome to CampuStay! Browse properties to get started.',time:'Just now',unread:true}
  ];
  if(myBookings.length>0) notifs.unshift({type:'booking',icon:'📋',text:'You have '+myBookings.length+' booking request(s).',time:'Now',unread:true});
  el.innerHTML=notifs.map(function(n){
    return '<div class="notif-item'+(n.unread?' unread':'')+'" onclick="markNotifRead(this)">'+
      '<div class="notif-icon '+n.type+'">'+n.icon+'</div>'+
      '<div style="flex:1"><div class="notif-text">'+n.text+'</div><div class="notif-time">'+n.time+'</div></div>'+
      (n.unread?'<div class="notif-unread-dot"></div>':'')+
    '</div>';
  }).join('');
}
function toggleNotifications() {
  var panel=document.getElementById('notifPanel'); if(!panel) return;
  var open=panel.classList.toggle('open');
  if(open){ var win=document.getElementById('chatWindow'); if(win){ win.classList.remove('open'); chatOpen=false; } }
}
function markNotifRead(el){ el.classList.remove('unread'); var d=el.querySelector('.notif-unread-dot'); if(d) d.remove(); }
function clearAllNotifications() {
  var el=document.getElementById('notif-list'); if(el) el.innerHTML='<div style="text-align:center;padding:2rem;color:var(--text3);font-size:.85rem">No new notifications 🎉</div>';
  showToast('Cleared','');
}

// ── Map ───────────────────────────────────────────────────
function initMap() {
  var mapEl=document.getElementById('prop-map'); if(!mapEl) return;
  if(leafletMap){ try{leafletMap.invalidateSize();}catch(e){} return; }
  try{
    leafletMap=L.map('prop-map').setView([20.5937,78.9629],5);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(leafletMap);
    var C={'Pune':[18.5204,73.8567],'Bangalore':[12.9716,77.5946],'Delhi':[28.6139,77.2090],'Mumbai':[19.0760,72.8777],'Hyderabad':[17.3850,78.4867],'Chennai':[13.0827,80.2707]};
    filteredProperties.forEach(function(p){
      var c=C[p.city]; if(!c) return;
      L.marker([c[0]+(Math.random()-.5)*.05,c[1]+(Math.random()-.5)*.05]).addTo(leafletMap)
        .bindPopup('<strong>'+p.name+'</strong><br>'+p.address+'<br>'+formatINR(p.price)+'/mo');
    });
  }catch(e){}
}

// ── Roommate finder ───────────────────────────────────────
function startRoommateSurvey() {
  document.getElementById('rm-intro-section').style.display='none';
  document.getElementById('rm-survey-section').style.display='';
  document.getElementById('rm-results-section').style.display='none';
  rmAnswers={}; showRoommateQ(0);
}
function showRoommateQ(idx) {
  var q=RM_QUESTIONS[idx];
  document.getElementById('rm-bar').style.width=Math.round(idx/RM_QUESTIONS.length*100)+'%';
  document.getElementById('rm-q-label').textContent='Question '+(idx+1)+' of '+RM_QUESTIONS.length;
  var html='<div style="font-family:\'Clash Display\',sans-serif;font-size:1.1rem;font-weight:700;margin-bottom:1.25rem;line-height:1.5">'+q.q+'</div>';
  html+=q.options.map(function(o){ return '<div class="rm-option" onclick="pickRoommateOpt(this,\''+q.key+'\',\''+o.replace(/'/g,'&#39;')+'\')"><div class="rm-option-radio"></div>'+o+'</div>'; }).join('');
  html+='<div style="display:flex;justify-content:space-between;margin-top:1.5rem">'+(idx>0?'<button class="btn btn-ghost btn-sm" onclick="showRoommateQ('+(idx-1)+')">← Back</button>':'<div></div>')+'<button class="btn btn-primary btn-sm" id="rm-next" onclick="nextRoommateQ('+idx+')" '+(rmAnswers[q.key]?'':'disabled')+'>'+(idx===RM_QUESTIONS.length-1?'Find Matches 🎉':'Next →')+'</button></div>';
  document.getElementById('rm-q-card').innerHTML=html;
}
function pickRoommateOpt(el,key,value){
  el.closest('.rm-q-card').querySelectorAll('.rm-option').forEach(function(o){o.classList.remove('selected');}); el.classList.add('selected'); rmAnswers[key]=value;
  var btn=document.getElementById('rm-next'); if(btn) btn.disabled=false;
}
function nextRoommateQ(idx){ if(idx<RM_QUESTIONS.length-1) showRoommateQ(idx+1); else showRoommateResults(); }
function showRoommateResults(){
  document.getElementById('rm-survey-section').style.display='none'; document.getElementById('rm-results-section').style.display='';
  document.getElementById('rm-bar').style.width='100%';
  var pr=document.getElementById('rm-prefs-row'); if(pr) pr.innerHTML=Object.values(rmAnswers).map(function(v){ return '<span class="rm-pill">'+v+'</span>'; }).join('');
  var m=MOCK_ROOMMATES.slice().sort(function(a,b){ return b.score-a.score; });
  document.getElementById('rm-match-count').textContent=m.length+' matches found';
  renderRoommateCards(m);
}
function renderRoommateCards(matches){
  var grid=document.getElementById('rm-results-grid'); if(!grid) return;
  var avatarColors=['linear-gradient(135deg,#f59e0b,#f97316)','linear-gradient(135deg,#2dd4bf,#06b6d4)','linear-gradient(135deg,#818cf8,#a78bfa)','linear-gradient(135deg,#fb923c,#f43f5e)'];
  grid.innerHTML=matches.map(function(m,i){
    var c=m.score>=90?'var(--green)':m.score>=80?'var(--accent)':'var(--text2)';
    var scoreBg=m.score>=90?'rgba(74,222,128,.12)':m.score>=80?'rgba(245,158,11,.12)':'rgba(148,163,184,.1)';
    var avatarBg=avatarColors[i%avatarColors.length];
    var firstName=m.name.split(' ')[0];
    return '<div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--r);padding:1.25rem 1.25rem 1rem;position:relative;display:flex;flex-direction:column;gap:.75rem;transition:border-color .2s;box-shadow:0 2px 8px rgba(0,0,0,.15)" onmouseover="this.style.borderColor=\'var(--accent)\'" onmouseout="this.style.borderColor=\'var(--border)\'">'+
      (i===0?'<div style="position:absolute;top:-10px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,var(--accent),var(--accent2));color:#0c0c10;padding:3px 14px;border-radius:100px;font-size:.6rem;font-weight:800;white-space:nowrap;letter-spacing:.05em">⭐ BEST MATCH</div>':'')+
      '<div style="display:flex;align-items:center;gap:12px">'+
        '<div style="width:52px;height:52px;border-radius:50%;background:'+avatarBg+';color:#fff;font-weight:700;font-size:1.2rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 2px 8px rgba(0,0,0,.2)">'+m.name[0]+'</div>'+
        '<div style="flex:1;min-width:0">'+
          '<div style="font-weight:700;font-size:.95rem;color:var(--text)">'+m.name+'</div>'+
          '<div style="font-size:.74rem;color:var(--text3);margin-top:1px">'+m.college+'</div>'+
          '<div style="font-size:.7rem;color:var(--text3)">'+m.year+'</div>'+
        '</div>'+
        '<div style="text-align:center;background:'+scoreBg+';border:1px solid '+c+';border-radius:var(--r2);padding:.4rem .65rem;flex-shrink:0">'+
          '<div style="font-size:1.25rem;font-weight:800;color:'+c+';line-height:1.1">'+m.score+'%</div>'+
          '<div style="font-size:.58rem;color:var(--text3);font-weight:600;text-transform:uppercase;letter-spacing:.05em;margin-top:1px">match</div>'+
        '</div>'+
      '</div>'+
      '<div style="display:flex;flex-wrap:wrap;gap:.35rem">'+
        m.hobbies.map(function(h){ return '<span style="background:var(--surface2);border:1px solid var(--border);color:var(--text2);font-size:.71rem;padding:3px 9px;border-radius:100px">'+h+'</span>'; }).join('')+
      '</div>'+
      '<div style="display:flex;align-items:center;gap:.5rem;font-size:.78rem;color:var(--text3);background:var(--surface2);border-radius:var(--r2);padding:.5rem .75rem">'+
        '<span>💤 '+m.sleep+'</span>'+
        '<span style="margin-left:auto">💰 '+m.budget+'</span>'+
      '</div>'+
      '<button class="btn btn-outline btn-sm" style="width:100%;justify-content:center;font-size:.82rem" onclick="chatWithRoommate(\''+m.name+'\')">💬 Connect with '+firstName+'</button>'+
    '</div>';
  }).join('');
}
function sortRoommates(){ renderRoommateCards(MOCK_ROOMMATES.slice().sort(function(a,b){ return b.score-a.score; })); }
function retakeRoommateSurvey(){ startRoommateSurvey(); }
function chatWithRoommate(name){
  var c=chatContacts.filter(function(x){ return x.name===name; })[0];
  if(!c){ c={id:'rc'+Date.now(),name:name,role:'Student',avatar:initials(name),color:'#2dd4bf',unread:0,messages:[{id:'m'+Date.now(),from:'them',text:"Hey! Saw we matched. Let's connect! 👋",time:'Now'}]}; chatContacts.unshift(c); }
  chatOpen=true; var win=document.getElementById('chatWindow'); if(win) win.classList.add('open');
  selectChatContact(c.id); showToast('Chat opened with '+name,'success');
}
document.addEventListener('click',function(e){ var p=document.getElementById('notifPanel'); if(p&&!e.target.closest('.notif-bell')&&!e.target.closest('#notifPanel')) p.classList.remove('open'); });
