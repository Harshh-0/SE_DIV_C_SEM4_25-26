// ============================================================
//  CampuStay — owner.js  (real API + localStorage persistence)
// ============================================================

var ownerProperties    = [];
var ownerRequests      = [];
var editingPropertyId  = null;
var uploadedImages     = [];   // base64 images from file input
var geocodedLat = null, geocodedLng = null, geocodeTimer = null;
var currentRequestFilter = 'all';

// ── Init ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  if (!requireAuth('owner')) return;
  populateNavUser();
  var user = getUser();
  if (user) { var ed=document.getElementById('user-email-display'); if(ed) ed.textContent=user.email||''; }
  loadOwnerData();
});

async function loadOwnerData() {
  try {
    var pd = await apiFetch('/properties/owner/mine');
    ownerProperties = pd.properties || [];
  } catch(e) { ownerProperties = []; }
  try {
    var bd = await apiFetch('/bookings/owner');
    ownerRequests = (bd.bookings || []).map(function(b){
      return { _id:b._id, propertyId:(b.property&&b.property._id)||b.property, studentName:(b.student&&b.student.name)||'Student',
        studentEmail:(b.student&&b.student.email)||'', college:(b.student&&b.student.college)||'', status:b.status,
        createdAt:b.createdAt, property:b.property||{} };
    });
  } catch(e) { ownerRequests = []; }
  renderOwnerProperties(); updateOwnerStats();
}

// ── Stats ─────────────────────────────────────────────────
function updateOwnerStats() {
  function set(id,v){ var el=document.getElementById(id); if(el) el.textContent=v; }
  set('stat-total',    ownerProperties.length);
  set('stat-approved', ownerProperties.filter(function(p){ return p.isApproved; }).length);
  set('stat-pending-props', ownerProperties.filter(function(p){ return !p.isApproved; }).length);
  set('stat-requests', ownerRequests.filter(function(r){ return r.status==='pending'; }).length);
}

// ── Tab switching ─────────────────────────────────────────
window.switchTab = function(id) {
  document.querySelectorAll('[id^="tab-"]').forEach(function(t){ t.style.display='none'; });
  var panel=document.getElementById('tab-'+id); if(panel) panel.style.display='';
  document.querySelectorAll('[id^="snav-"]').forEach(function(a){ a.classList.remove('active'); });
  var nav=document.getElementById('snav-'+id); if(nav) nav.classList.add('active');
  document.querySelectorAll('.sidebar-item[data-tab]').forEach(function(s){ s.classList.toggle('active',s.dataset.tab===id); });
  if(id==='requests') renderRequests();
};

// ── My Properties — card grid ─────────────────────────────
function renderOwnerProperties() {
  var el=document.getElementById('owner-properties'); if(!el) return;
  if(!ownerProperties.length){
    el.innerHTML='<div class="empty-state"><div class="empty-icon">🏘️</div><h3>No properties yet</h3><p>Add your first property to start receiving booking requests</p><button class="btn btn-primary" style="margin-top:1rem" onclick="switchTab(\'add\')">Add Property</button></div>'; return;
  }
  var html='<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(310px,1fr));gap:1.25rem">';
  ownerProperties.forEach(function(p){
    var stColor=p.isApproved?'var(--green)':'var(--accent)';
    var stBg=p.isApproved?'rgba(74,222,128,.08)':'rgba(245,158,11,.08)';
    var stBorder=p.isApproved?'rgba(74,222,128,.2)':'rgba(245,158,11,.2)';
    var stLabel=p.isApproved?'✅ Approved':'⏳ Pending Review';
    var pendingN=ownerRequests.filter(function(r){ return r.propertyId===(p._id||p.id)&&r.status==='pending'; }).length;
    var img=(p.photos&&p.photos[0])||'';
    var emoji=p.emoji||(p.type==='PG'?'🏠':'🏢');
    var chips=(p.amenities||[]).slice(0,4).map(function(a){ return '<span style="font-size:.65rem;padding:2px 8px;border-radius:100px;background:var(--surface2);border:1px solid var(--border);color:var(--text3)">'+a+'</span>'; }).join('');
    var headerInner=img
      ? '<img src="'+img+'" alt="'+p.name+'" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:.85" id="oi_'+(p._id||p.id)+'"/><div style="position:relative;z-index:1;font-size:3.5rem;text-shadow:0 2px 8px rgba(0,0,0,.5)">'+emoji+'</div>'
      : '<div style="opacity:.2;font-size:7rem;position:absolute">'+emoji+'</div><div style="position:relative;z-index:1;font-size:4rem">'+emoji+'</div>';
    html+='<div style="background:var(--surface);border:1px solid var(--border);border-radius:18px;overflow:hidden;transition:all .25s" onmouseover="this.style.borderColor=\'rgba(245,158,11,.35)\';this.style.transform=\'translateY(-3px)\';this.style.boxShadow=\'0 16px 48px rgba(0,0,0,.4)\'" onmouseout="this.style.borderColor=\'\';this.style.transform=\'\';this.style.boxShadow=\'\'">' +
      '<div style="height:160px;background:linear-gradient(135deg,var(--surface2),var(--bg3));display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden">'+
        headerInner+
        '<div style="position:absolute;top:10px;right:10px;background:'+stBg+';border:1px solid '+stBorder+';color:'+stColor+';font-size:.65rem;font-weight:700;padding:3px 10px;border-radius:100px;z-index:2">'+stLabel+'</div>'+
        (pendingN>0?'<div style="position:absolute;top:10px;left:10px;background:var(--rose);color:white;font-size:.65rem;font-weight:700;padding:3px 10px;border-radius:100px;z-index:2">'+pendingN+' new</div>':'')+
      '</div>'+
      '<div style="padding:1.25rem">'+
        '<div style="font-family:\'Clash Display\',sans-serif;font-size:1.05rem;font-weight:700;margin-bottom:4px">'+p.name+'</div>'+
        '<div style="font-size:.75rem;color:var(--text3);margin-bottom:.75rem">📍 '+p.address+', '+p.city+'</div>'+
        '<div style="display:flex;flex-wrap:wrap;gap:.3rem;margin-bottom:1rem">'+chips+'</div>'+
        '<div style="display:flex;align-items:center;justify-content:space-between;padding-top:.85rem;border-top:1px solid var(--border)">'+
          '<div><div style="font-family:\'Clash Display\',sans-serif;font-size:1.3rem;font-weight:800;color:var(--accent);line-height:1">'+formatINR(p.price)+'</div><div style="font-size:.65rem;color:var(--text3);margin-top:1px">'+p.roomsAvailable+' rooms · '+p.type+' · '+p.gender+'</div></div>'+
          '<div style="display:flex;gap:.5rem">'+
            '<button class="btn btn-outline btn-sm" onclick="editProperty(\''+(p._id||p.id)+'\')">✏️ Edit</button>'+
            '<button class="btn btn-danger btn-sm" onclick="confirmDelete(\''+(p._id||p.id)+'\')">🗑️</button>'+
          '</div>'+
        '</div>'+
      '</div>'+
    '</div>';
  });
  html+='</div>';
  el.innerHTML=html;
  // fix broken images
  ownerProperties.forEach(function(p){
    var pid=p._id||p.id; var img=document.getElementById('oi_'+pid);
    if(img) img.onerror=function(){ img.style.display='none'; };
  });
}

// ── Booking Requests ──────────────────────────────────────
function filterRequests(filter, btn) {
  currentRequestFilter=filter;
  document.querySelectorAll('[id^="req-filter-"]').forEach(function(b){ b.classList.remove('active'); });
  if(btn) btn.classList.add('active');
  renderRequests();
}

function renderRequests() {
  var el=document.getElementById('request-list'); if(!el) return;
  var pending=ownerRequests.filter(function(r){ return r.status==='pending'; }).length;
  var total=ownerRequests.length;
  var cA=document.getElementById('req-count-all'); if(cA) cA.textContent=total?'('+total+')':'';
  var cP=document.getElementById('req-count-pending'); if(cP) cP.textContent=pending?'('+pending+')':'';
  var filtered=currentRequestFilter==='all'?ownerRequests:ownerRequests.filter(function(r){ return r.status===currentRequestFilter; });
  if(!filtered.length){
    el.innerHTML='<div class="empty-state"><div class="empty-icon">📭</div><h3>No '+currentRequestFilter+' requests</h3></div>'; return;
  }
  el.innerHTML=filtered.map(function(r){
    var stColor=r.status==='approved'?'var(--green)':r.status==='rejected'?'var(--rose)':'var(--accent)';
    var stBg=r.status==='approved'?'rgba(74,222,128,.06)':r.status==='rejected'?'rgba(251,113,133,.06)':'rgba(245,158,11,.06)';
    var stBorder=r.status==='approved'?'rgba(74,222,128,.2)':r.status==='rejected'?'rgba(251,113,133,.2)':'rgba(245,158,11,.2)';
    var stLabel=r.status==='approved'?'✅ Approved':r.status==='rejected'?'✕ Declined':'⏳ Pending Review';
    var prop=r.property||{}; var propImg=(prop.photos&&prop.photos[0])||''; var propEmoji=prop.emoji||(prop.type==='PG'?'🏠':'🏢');
    var actions=r.status==='pending'
      ?'<button class="btn btn-success btn-sm" style="justify-content:center;width:100%" onclick="respondRequest(\''+r._id+'\',\'approved\')">✅ Approve</button><button class="btn btn-danger btn-sm" style="justify-content:center;width:100%;margin-top:.4rem" onclick="respondRequest(\''+r._id+'\',\'rejected\')">✕ Decline</button>'
      :r.status==='approved'?'<button class="btn btn-outline btn-sm" style="justify-content:center;width:100%" onclick="showToast(\'Contact: '+r.studentEmail+'\',\'\')">💬 Message</button>'
      :'<span style="font-size:.72rem;color:var(--text3);display:block;text-align:center;padding:.5rem 0">No action needed</span>';
    return '<div style="background:var(--surface);border:1px solid var(--border);border-radius:18px;overflow:hidden;margin-bottom:1.25rem">'+
      '<div style="padding:.55rem 1.25rem;background:'+stBg+';border-bottom:1px solid '+stBorder+';display:flex;align-items:center;justify-content:space-between">'+
        '<div style="display:flex;align-items:center;gap:8px"><div style="width:7px;height:7px;border-radius:50%;background:'+stColor+'"></div><span style="font-size:.75rem;font-weight:700;color:'+stColor+'">'+stLabel+'</span></div>'+
        '<span style="font-size:.68rem;color:var(--text3)">📅 '+formatDate(r.createdAt)+'</span>'+
      '</div>'+
      '<div style="display:flex;gap:1.25rem;padding:1.25rem;align-items:flex-start">'+
        '<div style="width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent2));color:#0c0c10;font-weight:800;font-size:1.2rem;display:flex;align-items:center;justify-content:center;flex-shrink:0">'+r.studentName[0]+'</div>'+
        '<div style="flex:1;min-width:0">'+
          '<div style="font-family:\'Clash Display\',sans-serif;font-size:1rem;font-weight:700;margin-bottom:3px">'+r.studentName+'</div>'+
          '<div style="font-size:.75rem;color:var(--text3);margin-bottom:.25rem">🎓 '+r.college+'</div>'+
          '<div style="font-size:.72rem;color:var(--text3);margin-bottom:.75rem">📧 '+r.studentEmail+'</div>'+
          '<div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:var(--surface2);border:1px solid var(--border);border-radius:100px;font-size:.7rem">'+
            '<span>'+propEmoji+'</span><span style="font-weight:600;color:var(--text2)">'+(prop.name||'Property')+'</span>'+
            '<span style="color:var(--text3)">·</span><span style="color:var(--accent)">'+formatINR(prop.price||0)+'/mo</span>'+
          '</div>'+
        '</div>'+
        '<div style="flex-shrink:0;min-width:115px">'+actions+'</div>'+
      '</div>'+
    '</div>';
  }).join('');
}

async function respondRequest(id, status) {
  try {
    await apiFetch('/bookings/'+id+'/status',{method:'PATCH',body:JSON.stringify({status:status})});
    showToast(status==='approved'?'✅ Booking approved!':'❌ Booking declined',status==='approved'?'success':'');
  } catch(e) { showToast(e.message||'Error','error'); }
  ownerRequests=ownerRequests.map(function(r){ return r._id===id?Object.assign({},r,{status:status}):r; });
  renderRequests(); updateOwnerStats();
}

// ── Edit / Delete ─────────────────────────────────────────
function editProperty(id) {
  var p=ownerProperties.filter(function(x){ return (x._id||x.id)===id; })[0]; if(!p) return;
  editingPropertyId=id; switchTab('add');
  document.getElementById('add-form-title').textContent='Edit Property';
  function sv(elId,v){ var el=document.getElementById(elId); if(el) el.value=v||''; }
  sv('p-name',p.name); sv('p-city',p.city); sv('p-address',p.address);
  sv('p-price',p.price); sv('p-rooms',p.roomsAvailable);
  sv('p-type',p.type); sv('p-gender',p.gender); sv('p-desc',p.description); sv('p-deposit',p.deposit);
  document.querySelectorAll('.amenity-cb input').forEach(function(cb){ cb.checked=(p.amenities||[]).indexOf(cb.value)!==-1; });
  document.getElementById('submit-prop-btn').textContent='Update Property';
}

function resetPropertyForm() {
  editingPropertyId=null; uploadedImages=[];
  document.getElementById('add-form-title').textContent='Add New Property';
  document.getElementById('submit-prop-btn').textContent='Submit for Review';
  ['p-name','p-city','p-address','p-price','p-rooms','p-desc','p-deposit'].forEach(function(id){ var el=document.getElementById(id); if(el) el.value=''; });
  var pt=document.getElementById('p-type'); if(pt) pt.value='';
  var pg=document.getElementById('p-gender'); if(pg) pg.value='';
  document.querySelectorAll('.amenity-cb input').forEach(function(cb){ cb.checked=false; });
  renderImgPreviews();
}

function confirmDelete(id) {
  var modal=document.getElementById('deleteModal'); if(!modal) return;
  modal.classList.remove('hidden');
  document.getElementById('confirmDeleteBtn').onclick=function(){ doDelete(id); modal.classList.add('hidden'); };
}

async function doDelete(id) {
  try { await apiFetch('/properties/'+id,{method:'DELETE'}); showToast('Property deleted',''); }
  catch(e) { showToast(e.message||'Error deleting','error'); }
  ownerProperties=ownerProperties.filter(function(p){ return (p._id||p.id)!==id; });
  renderOwnerProperties(); updateOwnerStats();
}

// ── Submit property (real API + photos as base64) ─────────
async function submitProperty() {
  function gv(id){ var el=document.getElementById(id); return el?el.value.trim():''; }
  var name=gv('p-name'), city=gv('p-city'), address=gv('p-address');
  var price=parseInt(gv('p-price')), rooms=parseInt(gv('p-rooms'))||1;
  var type=gv('p-type'), gender=gv('p-gender'), description=gv('p-desc');
  var deposit=gv('p-deposit'), notice=gv('p-notice');
  var state=gv('p-state')||city; // fallback
  var amenities=[]; document.querySelectorAll('.amenity-cb input:checked').forEach(function(c){ amenities.push(c.value); });
  if(!name||!city||!price||!type||!gender){ showToast('Please fill all required fields','error'); return; }
  if(!description){ showToast('Please add a description','error'); return; }

  // Photos: use base64 data from uploadedImages (stored server-side as base64 or URLs)
  var photos=uploadedImages.map(function(img){ return img.data; });

  var payload={ name:name, city:city, address:address, state:state||city, price:price,
    roomsAvailable:rooms, type:type, gender:gender, description:description,
    amenities:amenities, photos:photos,
    location:{ type:'Point', coordinates:[geocodedLng||0, geocodedLat||0] },
    deposit:deposit?parseInt(deposit):undefined, notice:notice||undefined };

  var btn=document.getElementById('submit-prop-btn');
  btn.innerHTML='<div class="spinner"></div> '+(editingPropertyId?'Updating...':'Submitting...');
  btn.disabled=true;

  try {
    var data;
    if(editingPropertyId){
      data=await apiFetch('/properties/'+editingPropertyId,{method:'PATCH',body:JSON.stringify(payload)});
      showToast('Property updated! ✅','success');
    } else {
      data=await apiFetch('/properties',{method:'POST',body:JSON.stringify(payload)});
      showToast('Property submitted for review! 📋 Admin will approve shortly.','success');
    }
    resetPropertyForm(); switchTab('properties');
    // Reload from server
    await loadOwnerData();
  } catch(err) {
    showToast(err.message||'Error saving property','error');
    btn.innerHTML=editingPropertyId?'Update Property':'Submit for Review';
    btn.disabled=false;
  }
}

// ── Image upload (stores as base64 for API upload) ────────
function handleImgUpload(input) {
  var files=Array.from(input.files);
  if(uploadedImages.length+files.length>6){ showToast('Max 6 photos allowed','error'); return; }
  files.forEach(function(file){
    if(file.size>10*1024*1024){ showToast(file.name+' too large (max 10MB)','error'); return; }
    var reader=new FileReader();
    reader.onload=function(e){ uploadedImages.push({name:file.name,data:e.target.result}); renderImgPreviews(); };
    reader.readAsDataURL(file);
  });
}
function handleImgDrop(e){ e.preventDefault(); if(e.dataTransfer&&e.dataTransfer.files) handleImgUpload({files:e.dataTransfer.files}); }
function renderImgPreviews() {
  var zone=document.getElementById('img-upload-zone');
  var previews=document.getElementById('img-previews'); if(!previews) return;
  previews.innerHTML=uploadedImages.map(function(img,i){
    return '<div style="position:relative;width:90px;height:80px;border-radius:var(--r2);overflow:hidden;border:1px solid var(--border)">'+
      '<img src="'+img.data+'" style="width:100%;height:100%;object-fit:cover"/>'+
      '<button onclick="removeImg('+i+')" style="position:absolute;top:3px;right:3px;width:20px;height:20px;border-radius:50%;background:rgba(0,0,0,.6);color:white;border:none;cursor:pointer;font-size:.7rem">✕</button>'+
      (i===0?'<div style="position:absolute;bottom:0;left:0;right:0;background:rgba(245,158,11,.85);font-size:.6rem;text-align:center;padding:2px;color:#0c0c10;font-weight:700">MAIN</div>':'')+
    '</div>';
  }).join('');
  if(uploadedImages.length>0&&zone){
    var icon=document.getElementById('img-upload-icon'); if(icon) icon.textContent='✅';
    zone.style.borderColor='var(--green)'; zone.style.background='rgba(74,222,128,.05)';
  } else if(zone){ zone.style.borderColor=''; zone.style.background=''; var icon2=document.getElementById('img-upload-icon'); if(icon2) icon2.textContent='📷'; }
}
function removeImg(i){ uploadedImages.splice(i,1); renderImgPreviews(); }

// ── Map / geocode ─────────────────────────────────────────
function updateMapEmbed(city,address) {
  clearTimeout(geocodeTimer); if(!city||!city.trim()) return;
  geocodeTimer=setTimeout(function(){
    var q=[address,city,'India'].filter(Boolean).join(', ');
    fetch('https://nominatim.openstreetmap.org/search?format=json&q='+encodeURIComponent(q)+'&limit=1')
      .then(function(r){ return r.json(); }).then(function(d){
        if(d.length){ geocodedLat=parseFloat(d[0].lat); geocodedLng=parseFloat(d[0].lon);
          showMapEmbed(geocodedLat,geocodedLng,q); var ci=document.getElementById('coord-info'); if(ci) ci.textContent='📍 Located: '+geocodedLat.toFixed(4)+', '+geocodedLng.toFixed(4); }
      }).catch(function(){});
  },800);
  showMapEmbed(null,null,[city,'India'].join(', '));
}
function showMapEmbed(lat,lng,query) {
  var iframe=document.getElementById('prop-map-iframe'); var noAddr=document.getElementById('map-no-addr'); if(!iframe) return;
  var src=lat&&lng?'https://maps.google.com/maps?q='+lat+','+lng+'&z=16&output=embed':'https://maps.google.com/maps?q='+encodeURIComponent(query||'')+'&output=embed&z=14';
  iframe.src=src; iframe.style.display=''; if(noAddr) noAddr.style.display='none';
}
function openMapsSearch() {
  var city=(document.getElementById('p-city')||{value:''}).value; var addr=(document.getElementById('p-address')||{value:''}).value;
  window.open('https://maps.google.com?q='+encodeURIComponent([addr,city,'India'].filter(Boolean).join(', ')),'_blank');
}
