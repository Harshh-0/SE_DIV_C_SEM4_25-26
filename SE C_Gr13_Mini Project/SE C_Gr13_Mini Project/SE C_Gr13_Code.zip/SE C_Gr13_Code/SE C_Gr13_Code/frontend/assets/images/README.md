# 📁 assets/images

This folder is for **local image assets** — logos, icons, placeholder images, etc.

## Currently

Images in the project are loaded from CDNs:

| Source | Used For |
|---|---|
| **Unsplash** | Property photos, city photos |
| **Fontshare CDN** | Clash Display + Satoshi fonts |
| **Google Fonts CDN** | Playfair Display |

## Adding Local Images

Place any `.jpg`, `.png`, `.svg`, or `.webp` files here and reference them as:

```html
<!-- From a page in /pages/ -->
<img src="../assets/images/your-image.jpg" alt="Description"/>

<!-- From index.html -->
<img src="assets/images/your-image.jpg" alt="Description"/>
```

## Recommended Files to Add

| Filename | Description |
|---|---|
| `logo.svg` | CampuStay logo vector |
| `og-image.jpg` | 1200×630 Open Graph social preview |
| `favicon.ico` | Browser tab icon |
| `favicon-32.png` | 32×32 PNG favicon |
| `apple-touch-icon.png` | 180×180 iOS home screen icon |
