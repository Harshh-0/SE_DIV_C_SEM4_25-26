# 📡 CampuStay API Reference

**Base URL:** `http://localhost:5000/api`  
**Auth:** All protected routes require `Authorization: Bearer <token>` header.

---

## Authentication

### POST `/auth/register`
Register a new user account.

**Body:**
```json
{
  "name":     "Ananya Sharma",
  "email":    "ananya@example.com",
  "password": "securepass123",
  "phone":    "+91 9876543210",
  "role":     "student",
  "college":  "Delhi University",
  "city":     "Delhi",
  "gender":   "Female"
}
```
**Response `201`:**
```json
{ "token": "eyJ...", "user": { "_id": "...", "name": "Ananya Sharma", "role": "student" } }
```

---

### POST `/auth/login`
Log in and receive a JWT token.

**Body:**
```json
{ "email": "ananya@student.com", "password": "demo123" }
```
**Response `200`:**
```json
{ "token": "eyJ...", "user": { ... } }
```

---

### GET `/auth/me` 🔒
Get the currently authenticated user.

**Response `200`:**
```json
{ "user": { "_id": "...", "name": "...", "role": "student", ... } }
```

---

### PATCH `/auth/change-password` 🔒
Change the current user's password.

**Body:**
```json
{ "currentPassword": "oldpass", "newPassword": "newpass123" }
```

---

## Properties

### GET `/properties`
Get all approved properties with optional filters.

**Query Parameters:**

| Param | Type | Example | Description |
|---|---|---|---|
| `city` | string | `Mumbai` | Filter by city (partial match) |
| `type` | string | `PG` or `Hostel` | Property type |
| `gender` | string | `Boys`, `Girls`, `Both` | Gender preference |
| `minPrice` | number | `5000` | Minimum monthly rent |
| `maxPrice` | number | `15000` | Maximum monthly rent |
| `amenities` | string | `WiFi,AC` | Comma-separated amenities |
| `page` | number | `1` | Page number |
| `limit` | number | `12` | Results per page |

**Response `200`:**
```json
{
  "properties": [ { "_id": "...", "name": "Sunrise Boys Hostel", ... } ],
  "total": 48,
  "page": 1,
  "pages": 4
}
```

---

### GET `/properties/:id`
Get a single property by ID.

**Response `200`:**
```json
{ "property": { "_id": "...", "name": "...", "owner": { "name": "Priya Nair" }, ... } }
```

---

### POST `/properties` 🔒 Owner
Create a new property listing.

**Body:**
```json
{
  "name":          "Green Valley PG",
  "description":   "Comfortable PG near campus...",
  "address":       "Koregaon Park",
  "city":          "Pune",
  "state":         "Maharashtra",
  "pincode":       "411001",
  "type":          "PG",
  "gender":        "Both",
  "price":         9000,
  "roomsAvailable": 5,
  "totalRooms":    20,
  "nearbyCollege": "Pune University",
  "distanceKm":    0.8,
  "amenities":     ["WiFi", "Meals", "Gym"],
  "location": {
    "type": "Point",
    "coordinates": [73.8938, 18.5362]
  }
}
```

---

### PATCH `/properties/:id` 🔒 Owner/Admin
Update property details.

---

### DELETE `/properties/:id` 🔒 Owner/Admin
Delete a property.

---

### GET `/properties/owner/mine` 🔒 Owner
Get all properties belonging to the authenticated owner.

---

### POST `/properties/:id/review` 🔒 Student
Add a review to a property.

**Body:**
```json
{ "rating": 5, "comment": "Excellent hostel, very clean!" }
```

---

## Bookings

### POST `/bookings` 🔒 Student
Create a new booking request.

**Body:**
```json
{
  "propertyId": "64abc...",
  "message":    "Hi, I'm looking for accommodation starting October.",
  "moveInDate": "2024-10-01",
  "duration":   6
}
```

---

### GET `/bookings/my` 🔒 Student
Get all bookings for the authenticated student.

**Response `200`:**
```json
{
  "bookings": [
    {
      "_id": "...",
      "property": { "name": "Sunrise Boys Hostel", ... },
      "status": "approved",
      "createdAt": "2024-09-10T..."
    }
  ]
}
```

---

### GET `/bookings/owner` 🔒 Owner
Get all booking requests for the owner's properties.

---

### PATCH `/bookings/:id/status` 🔒
Update booking status.

**Body:**
```json
{ "status": "approved" }
```
Valid values: `approved`, `rejected`, `cancelled`

**Permissions:**
- `approved` / `rejected` → Owner or Admin only
- `cancelled` → Student, Owner, or Admin

---

### GET `/bookings/admin/all` 🔒 Admin
Get all bookings platform-wide.

---

## Users

### GET `/users/profile` 🔒
Get the authenticated user's full profile.

---

### PATCH `/users/profile` 🔒
Update profile fields.

**Body (any combination):**
```json
{
  "name":    "Ananya Sharma",
  "phone":   "+91 9876543210",
  "college": "Delhi University",
  "city":    "Delhi",
  "gender":  "Female",
  "roommatePrefs": {
    "sleepTime":   "11 PM",
    "studyHabits": "4–6 hrs",
    "noiseLevel":  "Quiet only",
    "cleanliness": "4 – Clean",
    "smoking":     "Never",
    "budget":      "₹5K–8K",
    "genderPref":  "Same gender only",
    "surveyDone":  true
  }
}
```

---

### GET `/users/roommates` 🔒 Student
Get students with completed roommate surveys.

**Query Parameters:**

| Param | Type | Description |
|---|---|---|
| `city` | string | Filter by city |
| `budget` | string | Filter by budget range |

---

### POST `/users/save-property/:id` 🔒 Student
Toggle save/unsave a property.

**Response `200`:**
```json
{ "saved": true, "savedProperties": ["64abc...", "64def..."] }
```

---

## Admin

### GET `/admin/stats` 🔒 Admin
Get platform-wide statistics.

**Response `200`:**
```json
{
  "totalUsers":        1240,
  "totalProperties":   320,
  "totalBookings":     850,
  "pendingProperties": 12,
  "pendingBookings":   34,
  "students":          1100,
  "owners":            140
}
```

---

### GET `/admin/users` 🔒 Admin
Get all users with pagination.

**Query Parameters:** `role`, `page`, `limit`, `search`

---

### PATCH `/admin/users/:id/status` 🔒 Admin
Activate or deactivate a user account (toggles `isActive`).

---

### GET `/admin/properties/pending` 🔒 Admin
Get all unapproved property submissions.

---

### PATCH `/admin/properties/:id/approve` 🔒 Admin
Approve or reject a property.

**Body:**
```json
{ "approve": true }
```

---

### DELETE `/admin/properties/:id` 🔒 Admin
Permanently delete a property.

---

## Error Responses

All errors follow this format:

```json
{ "message": "Human-readable error description" }
```

| Status | Meaning |
|---|---|
| `400` | Bad Request — invalid data |
| `401` | Unauthorised — missing or invalid token |
| `403` | Forbidden — insufficient role permissions |
| `404` | Not Found |
| `409` | Conflict — duplicate entry |
| `500` | Internal Server Error |
