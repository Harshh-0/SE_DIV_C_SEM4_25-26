# 📋 CampuStay — Changelog

All notable changes are documented here.  
Format: `[Version] — Date`

---

## [4.0.0] — 2024

### 🚀 Major Release — Complete Redesign

#### Frontend — Homepage
- **NEW** Full hero section redesign with animated grid, floating orbs, cursor glow
- **NEW** Inline search widget directly in hero (City / Type / Budget / Gender)
- **NEW** Real Unsplash property photos on all cards
- **NEW** Property cards rebuilt from scratch — image zoom, rating pill, price overlay, amenity tags, owner info, Book Now button
- **NEW** Filter chips for property grid (Hostel, PG, Boys, Girls, WiFi, Meals, AC) — all functional
- **NEW** City explorer section with real city photos (Mumbai, Bangalore, Delhi, Pune, etc.)
- **NEW** Animated statistics counters with scroll trigger
- **NEW** Trust badge strip (Verified, Free, Instant Booking, Maps, Messaging)
- **IMPROVED** Hero typography — larger, tighter letter-spacing, gradient text
- **IMPROVED** Overall color palette — deeper dark background (#07070d)

#### Frontend — Student Dashboard
- **FIXED** Roommate Finder section now perfectly centered on all screen sizes
- **REMOVED** All "AI Matching", "AI Bio", "AI Tips" labels and buttons
- **IMPROVED** Roommate survey questions are cleaner and more descriptive
- **IMPROVED** Property cards inside dashboard match homepage quality
- **NEW** Chat auto-reply simulation with random responses
- **IMPROVED** Notification panel with per-item read/unread state

#### Frontend — Global
- **NEW** Consistent CSS design system with 40+ utility classes
- **NEW** Mobile-first responsive layout for all pages
- **NEW** Scroll reveal animations on all sections
- **IMPROVED** Navbar — cleaner, no Roommate Finder link

#### Backend
- **NEW** Complete Express REST API with 5 route groups
- **NEW** MongoDB schemas for User, Property, Booking, Message
- **NEW** JWT authentication with bcrypt password hashing
- **NEW** Role-based middleware (protect + authorize)
- **NEW** Global error handler with Mongoose error normalisation
- **NEW** Database seeder (seed.js) with demo data

#### Project Structure
- **NEW** Proper folder structure (frontend / backend / docs)
- **NEW** README.md with full documentation
- **NEW** docs/API.md — complete API reference
- **NEW** docs/SETUP.md — local and production setup guide
- **NEW** docs/FEATURES.md — feature list and roadmap
- **NEW** .gitignore, .env.example, package.json at root

---

## [3.0.0] — 2024

### Changes
- Initial full-stack version with basic property listing
- Student, Owner, Admin dashboards created
- Basic JWT authentication
- Roommate Finder page (separate page, light theme)
- Demo mode with localStorage

---

## [2.0.0] — 2024

### Changes
- Added Owner dashboard
- Added Admin dashboard
- Improved property cards
- Added booking system

---

## [1.0.0] — 2024

### Initial Release
- Homepage with hero section
- Login and signup pages
- Basic property listing
- Student dashboard skeleton
