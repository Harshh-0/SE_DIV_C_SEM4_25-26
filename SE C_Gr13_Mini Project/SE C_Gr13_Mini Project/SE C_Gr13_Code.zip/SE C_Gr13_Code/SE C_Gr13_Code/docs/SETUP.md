# 🛠️ CampuStay — Setup Guide

Complete step-by-step guide for setting up CampuStay locally or deploying to production.

---

## Prerequisites

| Tool | Version | Download |
|---|---|---|
| Node.js | v18 or higher | https://nodejs.org |
| MongoDB | v6 or higher | https://mongodb.com/try/download/community |
| Git | Any | https://git-scm.com |
| npm | v8+ (comes with Node) | — |

---

## Option 1 — Frontend Only (No Backend)

The entire frontend runs in **demo mode** using `localStorage` for state. No server needed.

```bash
# Clone the repo
git clone https://github.com/yourusername/campustay.git
cd campustay

# Open in browser (macOS)
open frontend/index.html

# Open in browser (Windows)
start frontend/index.html

# Or use a live server (recommended)
npx serve frontend
# → Visit http://localhost:3000
```

> **Demo credentials on the login page** — click any of the 3 demo buttons to log in instantly.

---

## Option 2 — Full Stack (Local)

### Step 1 — Clone the repository

```bash
git clone https://github.com/yourusername/campustay.git
cd campustay
```

### Step 2 — Install backend dependencies

```bash
cd backend
npm install
```

### Step 3 — Set up environment variables

```bash
cp .env.example .env
```

Open `.env` and fill in your values:

```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/campustay
JWT_SECRET=change_this_to_a_long_random_string
NODE_ENV=development
CLIENT_URL=http://localhost:5000
```

### Step 4 — Start MongoDB

```bash
# macOS (Homebrew)
brew services start mongodb-community

# Ubuntu/Debian
sudo systemctl start mongod

# Windows — start MongoDB service from Services panel
```

### Step 5 — Seed the database (optional)

```bash
# From the backend/ directory
node seed.js
```

This creates 4 users, 6 properties, and 1 booking.

### Step 6 — Start the server

```bash
# Development (auto-restarts on changes)
npm run dev

# Production
npm start
```

### Step 7 — Open the app

```
http://localhost:5000
```

---

## Option 3 — Deploy to Production

### Backend on Railway

1. Create account at https://railway.app
2. New Project → Deploy from GitHub → select your repo
3. Set root directory to `/backend`
4. Add environment variables in Railway dashboard:
   - `MONGO_URI` → your MongoDB Atlas connection string
   - `JWT_SECRET` → a long random string
   - `NODE_ENV=production`
5. Deploy

### Frontend on Vercel (Static)

1. Create account at https://vercel.com
2. New Project → Import from GitHub
3. Set root directory to `/frontend`
4. Framework Preset: **Other**
5. Deploy

Update the `API_BASE` constant in `frontend/js/main.js` to point to your Railway backend URL.

### MongoDB Atlas (Cloud DB)

1. Create free cluster at https://cloud.mongodb.com
2. Add database user (username + password)
3. Whitelist IP: `0.0.0.0/0` (all IPs) for Railway
4. Copy the connection string and set as `MONGO_URI`

---

## Running Tests

```bash
cd backend
npm test
```

---

## Common Issues

**`MongooseServerSelectionError`**  
MongoDB is not running. Start it with `brew services start mongodb-community` (macOS) or `sudo systemctl start mongod` (Linux).

**`Port 5000 already in use`**  
Change `PORT` in `.env` to `5001` or kill the process using:
```bash
lsof -ti:5000 | xargs kill
```

**Fonts not loading**  
The app uses Fontshare CDN for fonts. Ensure you have internet access, or the app will fall back to system sans-serif.

**Images not showing**  
Property images are loaded from Unsplash. Ensure internet access or replace image URLs in `frontend/js/student.js`.

---

## File Serving

The Express backend serves the frontend statically:

```
GET /          → frontend/index.html
GET /pages/*   → frontend/pages/*.html
GET /css/*     → frontend/css/*.css
GET /js/*      → frontend/js/*.js
GET /api/*     → API handlers
```

This means you only need **one server** for both frontend and backend in production.
