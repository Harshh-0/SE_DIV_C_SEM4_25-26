// ============================================================
//  CampuStay v4 — controllers/propertyController.js
// ============================================================

const Property = require('../models/Property');

// ── GET /api/properties ─────────────────────────────────────
// Query: city, type, gender, minPrice, maxPrice, amenities, page, limit
exports.getProperties = async (req, res) => {
  try {
    const {
      city, type, gender, minPrice, maxPrice,
      amenities, page = 1, limit = 12, approved = true,
    } = req.query;

    const filter = { isActive: true };
    if (approved !== 'all') filter.isApproved = approved === 'true';
    if (city)     filter.city     = new RegExp(city, 'i');
    if (type)     filter.type     = type;
    if (gender && gender !== 'Both') filter.gender = { $in: [gender, 'Both'] };
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }
    if (amenities) {
      filter.amenities = { $all: amenities.split(',') };
    }

    const skip  = (Number(page) - 1) * Number(limit);
    const total = await Property.countDocuments(filter);
    const props = await Property.find(filter)
      .populate('owner', 'name email phone')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));

    res.json({ properties: props, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ── GET /api/properties/:id ─────────────────────────────────
exports.getProperty = async (req, res) => {
  try {
    const prop = await Property.findById(req.params.id)
      .populate('owner', 'name email phone');
    if (!prop) return res.status(404).json({ message: 'Property not found' });
    res.json({ property: prop });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ── POST /api/properties ────────────────────────────────────
exports.createProperty = async (req, res) => {
  try {
    const body = { ...req.body };
    // Default state to city if not provided
    if (!body.state) body.state = body.city || '';
    // Limit base64 photo size (keep up to 6)
    if (Array.isArray(body.photos)) body.photos = body.photos.slice(0, 6);
    const prop = await Property.create({ ...body, owner: req.user._id, isApproved: false });
    await prop.populate('owner', 'name email phone');
    res.status(201).json({ property: prop });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// ── PATCH /api/properties/:id ───────────────────────────────
exports.updateProperty = async (req, res) => {
  try {
    const prop = await Property.findById(req.params.id);
    if (!prop) return res.status(404).json({ message: 'Property not found' });
    if (prop.owner.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorised' });
    }
    const updated = await Property.findByIdAndUpdate(req.params.id, req.body, {
      new: true, runValidators: true,
    });
    res.json({ property: updated });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// ── DELETE /api/properties/:id ──────────────────────────────
exports.deleteProperty = async (req, res) => {
  try {
    const prop = await Property.findById(req.params.id);
    if (!prop) return res.status(404).json({ message: 'Property not found' });
    if (prop.owner.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorised' });
    }
    await prop.deleteOne();
    res.json({ message: 'Property deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ── GET /api/properties/owner/mine ──────────────────────────
exports.getOwnerProperties = async (req, res) => {
  try {
    const props = await Property.find({ owner: req.user._id })
      .sort({ createdAt: -1 });
    res.json({ properties: props });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ── POST /api/properties/:id/review ─────────────────────────
exports.addReview = async (req, res) => {
  try {
    const { rating, comment } = req.body;
    const prop = await Property.findById(req.params.id);
    if (!prop) return res.status(404).json({ message: 'Property not found' });

    // Check if user already reviewed
    const alreadyReviewed = prop.reviews.find(
      r => r.user.toString() === req.user._id.toString()
    );
    if (alreadyReviewed) {
      return res.status(400).json({ message: 'You have already reviewed this property' });
    }

    prop.reviews.push({ user: req.user._id, rating, comment });
    prop.updateRating();
    await prop.save();
    res.status(201).json({ message: 'Review added', avgRating: prop.avgRating });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};
