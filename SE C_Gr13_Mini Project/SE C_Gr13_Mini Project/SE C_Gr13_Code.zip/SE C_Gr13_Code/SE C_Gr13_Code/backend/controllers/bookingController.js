// ============================================================
//  CampuStay v4 — controllers/bookingController.js
// ============================================================

const Booking  = require('../models/Booking');
const Property = require('../models/Property');

// ── POST /api/bookings ──────────────────────────────────────
exports.createBooking = async (req, res) => {
  try {
    const { propertyId, message, moveInDate, duration } = req.body;

    const property = await Property.findById(propertyId);
    if (!property || !property.isApproved) {
      return res.status(404).json({ message: 'Property not found' });
    }
    if (property.roomsAvailable < 1) {
      return res.status(400).json({ message: 'No rooms available' });
    }

    // Prevent duplicate pending bookings
    const existing = await Booking.findOne({
      student: req.user._id,
      property: propertyId,
      status: { $in: ['pending', 'approved'] },
    });
    if (existing) {
      return res.status(409).json({ message: 'You already have an active booking for this property' });
    }

    const booking = await Booking.create({
      property: propertyId,
      student:  req.user._id,
      owner:    property.owner,
      message,
      moveInDate,
      duration,
      monthlyRent: property.price,
    });

    await booking.populate(['property', 'student']);
    res.status(201).json({ booking });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// ── GET /api/bookings/my ─────────────────────────────────────
exports.getMyBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ student: req.user._id })
      .populate('property', 'name address city type price photos emoji')
      .sort({ createdAt: -1 });
    res.json({ bookings });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ── GET /api/bookings/owner ──────────────────────────────────
exports.getOwnerBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ owner: req.user._id })
      .populate('property', 'name address city')
      .populate('student', 'name email phone college')
      .sort({ createdAt: -1 });
    res.json({ bookings });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ── PATCH /api/bookings/:id/status ──────────────────────────
exports.updateBookingStatus = async (req, res) => {
  try {
    const { status, cancelReason } = req.body;
    const booking = await Booking.findById(req.params.id);
    if (!booking) return res.status(404).json({ message: 'Booking not found' });

    // Owner can approve/reject; student can cancel
    const isOwner   = booking.owner.toString()   === req.user._id.toString();
    const isStudent = booking.student.toString()  === req.user._id.toString();
    const isAdmin   = req.user.role === 'admin';

    if (!isOwner && !isStudent && !isAdmin) {
      return res.status(403).json({ message: 'Not authorised' });
    }

    if (status === 'approved' && !isOwner && !isAdmin) {
      return res.status(403).json({ message: 'Only owners can approve bookings' });
    }

    booking.status = status;
    if (status === 'approved') booking.approvedAt = new Date();
    if (status === 'rejected') booking.rejectedAt = new Date();
    if (status === 'cancelled') {
      booking.cancelledAt = new Date();
      booking.cancelReason = cancelReason;
    }

    await booking.save();
    res.json({ booking });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// ── GET /api/bookings/admin/all ──────────────────────────────
exports.getAllBookings = async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate('property', 'name city type')
      .populate('student', 'name email')
      .populate('owner',   'name email')
      .sort({ createdAt: -1 })
      .limit(100);
    res.json({ bookings });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
