// ============================================================
//  CampuStay v4 — controllers/adminController.js
// ============================================================

const User     = require('../models/User');
const Property = require('../models/Property');
const Booking  = require('../models/Booking');

// ── GET /api/admin/stats ─────────────────────────────────────
exports.getStats = async (req, res) => {
  try {
    const [totalUsers, totalProperties, totalBookings, pendingProperties, pendingBookings] =
      await Promise.all([
        User.countDocuments({ isActive: true }),
        Property.countDocuments({ isApproved: true }),
        Booking.countDocuments(),
        Property.countDocuments({ isApproved: false }),
        Booking.countDocuments({ status: 'pending' }),
      ]);

    const students = await User.countDocuments({ role: 'student' });
    const owners   = await User.countDocuments({ role: 'owner' });

    res.json({ totalUsers, totalProperties, totalBookings, pendingProperties, pendingBookings, students, owners });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ── GET /api/admin/users ─────────────────────────────────────
exports.getUsers = async (req, res) => {
  try {
    const { role, page = 1, limit = 20, search } = req.query;
    const filter = {};
    if (role)   filter.role = role;
    if (search) filter.$or = [
      { name:  new RegExp(search, 'i') },
      { email: new RegExp(search, 'i') },
    ];

    const skip  = (Number(page) - 1) * Number(limit);
    const total = await User.countDocuments(filter);
    const users = await User.find(filter)
      .select('-password')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));

    res.json({ users, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ── PATCH /api/admin/users/:id/status ───────────────────────
exports.toggleUserStatus = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    if (user.role === 'admin') return res.status(403).json({ message: 'Cannot modify admin accounts' });

    user.isActive = !user.isActive;
    await user.save();
    res.json({ user, message: `User ${user.isActive ? 'activated' : 'deactivated'}` });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ── GET /api/admin/properties/pending ───────────────────────
exports.getPendingProperties = async (req, res) => {
  try {
    const props = await Property.find({ isApproved: false })
      .populate('owner', 'name email phone')
      .sort({ createdAt: -1 });
    res.json({ properties: props });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ── PATCH /api/admin/properties/:id/approve ─────────────────
exports.approveProperty = async (req, res) => {
  try {
    const { approve } = req.body; // true = approve, false = reject
    const prop = await Property.findByIdAndUpdate(
      req.params.id,
      { isApproved: approve },
      { new: true }
    ).populate('owner', 'name email');

    if (!prop) return res.status(404).json({ message: 'Property not found' });
    res.json({ property: prop, message: `Property ${approve ? 'approved' : 'rejected'}` });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ── DELETE /api/admin/properties/:id ────────────────────────
exports.deleteProperty = async (req, res) => {
  try {
    const prop = await Property.findByIdAndDelete(req.params.id);
    if (!prop) return res.status(404).json({ message: 'Property not found' });
    res.json({ message: 'Property deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
