const bcrypt = require('bcrypt');

bcrypt.hash("demo123", 10).then(hash => {
  console.log("Hashed password:", hash);
});