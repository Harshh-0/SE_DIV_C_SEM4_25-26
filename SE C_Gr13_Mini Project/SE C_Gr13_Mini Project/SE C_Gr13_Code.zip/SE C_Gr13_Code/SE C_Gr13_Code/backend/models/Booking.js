// ============================================================
//  CampuStay v4 — models/Booking.js
// ============================================================

const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema(
  {
    property: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Property',
      required: true,
    },
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected', 'cancelled'],
      default: 'pending',
    },
    message: {
      type: String,
      maxlength: 500,
      default: '',
    },
    moveInDate: { type: Date },
    duration:   { type: Number }, // months
    monthlyRent:{ type: Number },

    // Timestamps for status changes
    approvedAt:  { type: Date },
    rejectedAt:  { type: Date },
    cancelledAt: { type: Date },
    cancelReason:{ type: String },
  },
  { timestamps: true }
);

bookingSchema.index({ student: 1, status: 1 });
bookingSchema.index({ owner: 1, status: 1 });
bookingSchema.index({ property: 1 });

module.exports = mongoose.model('Booking', bookingSchema);
