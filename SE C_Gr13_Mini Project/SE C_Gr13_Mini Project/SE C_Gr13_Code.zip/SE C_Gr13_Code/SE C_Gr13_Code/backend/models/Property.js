// ============================================================
//  CampuStay v4 — models/Property.js
// ============================================================

const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema(
  {
    user:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    rating:  { type: Number, min: 1, max: 5, required: true },
    comment: { type: String, maxlength: 500 },
  },
  { timestamps: true }
);

const propertySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Property name is required'],
      trim: true,
      maxlength: [100, 'Name cannot exceed 100 characters'],
    },
    description: { type: String, required: true, maxlength: 2000 },
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    // Location
    address:  { type: String, required: true },
    city:     { type: String, required: true },
    state:    { type: String, default: '' },
    pincode:  { type: String },
    location: {
      type:        { type: String, enum: ['Point'], default: 'Point' },
      coordinates: { type: [Number], default: [0, 0] }, // [lng, lat]
    },

    // Property details
    type:           { type: String, enum: ['PG', 'Hostel', 'Flat'], required: true },
    gender:         { type: String, enum: ['Boys', 'Girls', 'Both'], required: true },
    price:          { type: Number, required: true, min: 0 },
    roomsAvailable: { type: Number, default: 1, min: 0 },
    totalRooms:     { type: Number, default: 1 },
    nearbyCollege:  { type: String },
    distanceKm:     { type: Number },

    // Amenities
    amenities: [{ type: String }],

    // Photos
    photos: [{ type: String }], // Cloudinary URLs or local paths

    // Status
    isApproved: { type: Boolean, default: false },
    isActive:   { type: Boolean, default: true },

    // Reviews & rating
    reviews: [reviewSchema],
    avgRating: { type: Number, default: 0 },
    totalReviews: { type: Number, default: 0 },
  },
  { timestamps: true }
);

// Geo index for map queries
propertySchema.index({ location: '2dsphere' });
propertySchema.index({ city: 1, type: 1, gender: 1, price: 1 });

// Auto-update avgRating when reviews change
propertySchema.methods.updateRating = function () {
  if (this.reviews.length === 0) {
    this.avgRating = 0;
    this.totalReviews = 0;
  } else {
    const sum = this.reviews.reduce((acc, r) => acc + r.rating, 0);
    this.avgRating = Math.round((sum / this.reviews.length) * 10) / 10;
    this.totalReviews = this.reviews.length;
  }
};

module.exports = mongoose.model('Property', propertySchema);
