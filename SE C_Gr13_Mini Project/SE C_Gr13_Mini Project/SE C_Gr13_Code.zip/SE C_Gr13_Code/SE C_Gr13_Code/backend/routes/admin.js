// ============================================================
//  CampuStay — routes/admin.js
// ============================================================
const express  = require('express');
const router   = express.Router();
const Property = require('../models/Property');
const User     = require('../models/User');
const Booking  = require('../models/Booking');
const { protect, authorize } = require('../middleware/auth');

const isAdmin = [protect, authorize('admin')];

// ── GET /api/admin/stats ──────────────────────────────────
router.get('/stats', isAdmin, async (req, res) => {
  try {
    const [totalUsers, totalProperties, totalBookings, pendingProperties] = await Promise.all([
      User.countDocuments({ isActive: true }),
      Property.countDocuments(),
      Booking.countDocuments(),
      Property.countDocuments({ isApproved: false }),
    ]);
    const students = await User.countDocuments({ role: 'student', isActive: true });
    const owners   = await User.countDocuments({ role: 'owner',   isActive: true });
    res.json({ totalUsers, totalProperties, totalBookings, pendingProperties, students, owners });
  } catch(e) { res.status(500).json({ message: e.message }); }
});

// ── GET /api/admin/properties ─────────────────────────────
router.get('/properties', isAdmin, async (req, res) => {
  try {
    // No isActive filter — return all properties so admin can see everything
    const filter = {};
    if (req.query.approved === 'pending')  filter.isApproved = false;
    else if (req.query.approved === 'approved') filter.isApproved = true;
    const props = await Property.find(filter)
      .populate('owner', 'name email phone')
      .sort({ createdAt: -1 })
      .limit(200);
    res.json({ properties: props });
  } catch(e) { res.status(500).json({ message: e.message }); }
});

// ── PATCH /api/admin/properties/:id/approve ───────────────
router.patch('/properties/:id/approve', isAdmin, async (req, res) => {
  try {
    const prop = await Property.findByIdAndUpdate(
      req.params.id, { isApproved: true }, { new: true }
    );
    if (!prop) return res.status(404).json({ message: 'Property not found' });
    res.json({ property: prop });
  } catch(e) { res.status(500).json({ message: e.message }); }
});

// ── DELETE /api/admin/properties/:id ─────────────────────
router.delete('/properties/:id', isAdmin, async (req, res) => {
  try {
    await Property.findByIdAndDelete(req.params.id);
    res.json({ message: 'Property deleted' });
  } catch(e) { res.status(500).json({ message: e.message }); }
});

// ── GET /api/admin/users ──────────────────────────────────
router.get('/users', isAdmin, async (req, res) => {
  try {
    // Return ALL users (no isActive filter) so admin can manage deactivated ones too
    const users = await User.find({}).select('-password').sort({ createdAt: -1 }).limit(500);

    // Attach booking count per student
    const counts = await Booking.aggregate([
      { $group: { _id: '$student', count: { $sum: 1 } } }
    ]);
    const countMap = {};
    counts.forEach(c => { if (c._id) countMap[c._id.toString()] = c.count; });

    const result = users.map(u => {
      const obj = u.toObject();
      obj.bookings = countMap[u._id.toString()] || 0;
      return obj;
    });

    res.json({ users: result, total: result.length });
  } catch(e) { res.status(500).json({ message: e.message }); }
});

// ── PATCH /api/admin/users/:id/verify ────────────────────
router.patch('/users/:id/verify', isAdmin, async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isVerified: true, verifyStatus: 'verified' },
      { new: true }
    );
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({ user });
  } catch(e) { res.status(500).json({ message: e.message }); }
});

// ── PATCH /api/admin/users/:id/reject-verify ─────────────
router.patch('/users/:id/reject-verify', isAdmin, async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isVerified: false, verifyStatus: 'unverified' },
      { new: true }
    );
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({ user });
  } catch(e) { res.status(500).json({ message: e.message }); }
});

// ── PATCH /api/admin/users/:id/status ────────────────────
router.patch('/users/:id/status', isAdmin, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    if (user.role === 'admin') return res.status(403).json({ message: 'Cannot modify admin accounts' });
    user.isActive = !user.isActive;
    await user.save();
    res.json({ user, message: `User ${user.isActive ? 'activated' : 'deactivated'}` });
  } catch(e) { res.status(500).json({ message: e.message }); }
});

// ── DELETE /api/admin/users/:id ───────────────────────────
router.delete('/users/:id', isAdmin, async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.params.id, { isActive: false });
    res.json({ message: 'User deactivated' });
  } catch(e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
