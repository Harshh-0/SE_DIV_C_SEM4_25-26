// ============================================================
//  CampuStay v4 — routes/properties.js
// ============================================================

const express = require('express');
const router  = express.Router();
const {
  getProperties, getProperty, createProperty,
  updateProperty, deleteProperty, getOwnerProperties, addReview,
} = require('../controllers/propertyController');
const { protect, authorize } = require('../middleware/auth');

router.get('/',              getProperties);
router.get('/owner/mine',    protect, authorize('owner'), getOwnerProperties);
router.get('/:id',           getProperty);
router.post('/',             protect, authorize('owner', 'admin'), createProperty);
router.patch('/:id',         protect, authorize('owner', 'admin'), updateProperty);
router.delete('/:id',        protect, authorize('owner', 'admin'), deleteProperty);
router.post('/:id/review',   protect, authorize('student'), addReview);

module.exports = router;
