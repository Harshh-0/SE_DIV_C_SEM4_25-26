// ============================================================
//  CampuStay v4 — routes/bookings.js
// ============================================================

const express = require('express');
const router  = express.Router();
const {
  createBooking, getMyBookings, getOwnerBookings,
  updateBookingStatus, getAllBookings,
} = require('../controllers/bookingController');
const { protect, authorize } = require('../middleware/auth');

router.post('/',              protect, authorize('student'), createBooking);
router.get('/my',             protect, authorize('student'), getMyBookings);
router.get('/owner',          protect, authorize('owner'),   getOwnerBookings);
router.get('/admin/all',      protect, authorize('admin'),   getAllBookings);
router.patch('/:id/status',   protect, updateBookingStatus);

module.exports = router;
