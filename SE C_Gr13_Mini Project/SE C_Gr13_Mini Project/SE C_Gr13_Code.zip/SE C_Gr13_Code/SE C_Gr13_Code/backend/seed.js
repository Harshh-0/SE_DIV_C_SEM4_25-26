// ============================================================
//  CampuStay — seed.js
//  Run: node seed.js
//  Creates demo accounts: student, owner, admin
// ============================================================

const mongoose = require('mongoose');
const dotenv   = require('dotenv');
dotenv.config();

const User     = require('./models/User');
const Property = require('./models/Property');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/campustay';

async function seed() {
  await mongoose.connect(MONGO_URI);
  console.log('✅ Connected to MongoDB');

  // Clear existing demo accounts
  await User.deleteMany({ email: { $in: ['ananya@student.com','priya@owner.com','admin@campustay.com'] } });

  // Create accounts
  const student = await User.create({ name:'Ananya Sharma', email:'ananya@student.com', password:'demo123', role:'student', college:'Delhi University', phone:'+91 9876543210' });
  const owner   = await User.create({ name:'Priya Nair',    email:'priya@owner.com',    password:'demo123', role:'owner',   phone:'+91 9876500001' });
  const admin   = await User.create({ name:'Admin User',    email:'admin@campustay.com',password:'demo123', role:'admin' });
  console.log('✅ Demo users created');

  // Create 2 sample approved properties for the owner
  await Property.deleteMany({ owner: owner._id });
  await Property.create([
    { name:'Sunrise Boys Hostel', address:'Koregaon Park, Pune', city:'Pune', state:'Maharashtra',
      price:8500, type:'Hostel', gender:'Boys', description:'Spacious hostel near Pune University with great amenities.',
      amenities:['WiFi','Meals','Laundry','Hot Water'], roomsAvailable:4, owner:owner._id, isApproved:true,
      photos:['https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=600&q=80'] },
    { name:"Scholar's Den", address:'Lajpat Nagar, Delhi', city:'Delhi', state:'Delhi',
      price:7500, type:'Hostel', gender:'Boys', description:'Budget hostel with dedicated study rooms.',
      amenities:['WiFi','Study Room','Meals','Power Backup'], roomsAvailable:8, owner:owner._id, isApproved:false,
      photos:['https://images.unsplash.com/photo-1560448204-603b3fc33ddc?w=600&q=80'] }
  ]);
  console.log('✅ Sample properties created');

  console.log('\n🎓 Demo accounts:');
  console.log('  Student → ananya@student.com  / demo123');
  console.log('  Owner   → priya@owner.com     / demo123');
  console.log('  Admin   → admin@campustay.com / demo123\n');

  await mongoose.disconnect();
  process.exit(0);
}

seed().catch(err => { console.error('❌ Seed error:', err.message); process.exit(1); });
